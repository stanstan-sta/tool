package com.mindcraft.bridge;

import java.util.Locale;
import net.minecraft.class_1799;
import net.minecraft.class_2248;

public final class ItemIds {
    private ItemIds() {}

    public static String normalize(String item) {
        String id = String.valueOf(item == null ? "" : item).trim().toLowerCase(Locale.ROOT);
        return id.contains(":") ? id : "minecraft:" + id;
    }

    public static String strip(String itemId) {
        String normalized = normalize(itemId);
        return normalized.startsWith("minecraft:") ? normalized.substring(10) : normalized;
    }

    public static String fromStack(class_1799 stack) {
        if (stack.method_7960()) return "";
        String s = stack.method_7909().toString();
        if (s.startsWith("Item{") && s.endsWith("}")) {
            return s.substring(5, s.length() - 1);
        }
        return s;
    }

    public static String fromBlock(class_2248 block) {
        String s = block.toString();
        if (s.startsWith("Block{") && s.endsWith("}")) {
            return s.substring(6, s.length() - 1);
        }
        return s;
    }
}
