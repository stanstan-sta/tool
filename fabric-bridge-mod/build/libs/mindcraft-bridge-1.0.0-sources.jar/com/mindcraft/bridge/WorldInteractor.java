package com.mindcraft.bridge;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;

public final class WorldInteractor {
    private WorldInteractor() {}

    public static boolean openBlock(class_2338 pos) {
        return interactBlock(pos, class_2350.field_11036);
    }

    public static boolean interactBlock(class_2338 pos, class_2350 direction) {
        return interactBlock(pos, direction, class_1268.field_5808);
    }

    public static boolean interactBlock(class_2338 pos, class_2350 direction, class_1268 hand) {
        return Boolean.TRUE.equals(ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 player = client.field_1724;
            class_636 im = client.field_1761;
            if (player == null || im == null || client.field_1687 == null) return false;
            class_243 hit = class_243.method_24953(pos);
            class_3965 bhr = new class_3965(hit, direction, pos, false);
            im.method_2896(player, hand == null ? class_1268.field_5808 : hand, bhr);
            return true;
        }));
    }

    public static boolean interactEntity(int entityId) {
        return interactEntity(entityId, class_1268.field_5808);
    }

    public static boolean interactEntity(int entityId, class_1268 hand) {
        return Boolean.TRUE.equals(ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 player = client.field_1724;
            class_636 im = client.field_1761;
            if (player == null || im == null || client.field_1687 == null) return false;
            var entity = client.field_1687.method_8469(entityId);
            if (entity == null) return false;
            im.method_2905(player, entity, hand == null ? class_1268.field_5808 : hand);
            return true;
        }));
    }

    public static boolean placeBlock(class_2338 pos, class_2350 direction) {
        return interactBlock(pos, direction);
    }

    public static boolean breakBlock(class_2338 pos) {
        return Boolean.TRUE.equals(ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 player = client.field_1724;
            class_636 im = client.field_1761;
            if (player == null || im == null || client.field_1687 == null) return false;
            im.method_2902(pos, class_2350.field_11036);
            return true;
        }));
    }
}
