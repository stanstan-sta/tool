package com.mindcraft.bridge;

import net.minecraft.class_310;
import net.minecraft.class_746;

final class VehicleDriver {
    private VehicleDriver() {}

    static boolean dismount() {
        return ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p == null || !p.method_5765()) return false;
            p.method_29239();
            return true;
        });
    }

    static boolean isMounted() {
        return ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            return p != null && p.method_5765();
        });
    }

    static int getVehicleEntityId() {
        return ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p == null || !p.method_5765()) return -1;
            return p.method_5854().method_5628();
        });
    }
}
