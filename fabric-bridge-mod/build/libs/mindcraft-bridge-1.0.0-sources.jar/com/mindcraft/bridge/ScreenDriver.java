package com.mindcraft.bridge;

import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_746;

public final class ScreenDriver {
    private ScreenDriver() {}

    public static boolean waitForHandler(Class<?> handlerClass, long timeoutMs) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            Boolean open = ClientThread.call(() -> {
                class_746 p = class_310.method_1551().field_1724;
                return p != null && handlerClass.isInstance(p.field_7512);
            });
            if (Boolean.TRUE.equals(open)) return true;
            sleep(50);
        }
        return false;
    }

    public static boolean click(int slot, int button, class_1713 actionType) {
        return click(slot, button, actionType, null);
    }

    public static boolean click(int slot, int button, class_1713 actionType, Class<? extends class_1703> expectedHandlerType) {
        boolean ok = Boolean.TRUE.equals(ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 p = client.field_1724;
            class_636 im = client.field_1761;
            if (p == null || im == null) return false;
            class_1703 handler = p.field_7512;
            if (!isUsableHandler(handler, slot, expectedHandlerType)) return false;
            im.method_2906(handler.field_7763, slot, button, actionType, p);
            return true;
        }));
        sleep(50L);
        return ok;
    }

    public static boolean quickMove(int slot) {
        return quickMove(slot, null);
    }

    public static boolean quickMove(int slot, Class<? extends class_1703> expectedHandlerType) {
        return click(slot, 0, class_1713.field_7794, expectedHandlerType);
    }

    public static boolean pickup(int slot) {
        return pickup(slot, null);
    }

    public static boolean pickup(int slot, Class<? extends class_1703> expectedHandlerType) {
        return click(slot, 0, class_1713.field_7790, expectedHandlerType);
    }

    static boolean swap(int sourceSlot, int targetSlot) {
        return swap(sourceSlot, targetSlot, null);
    }

    static boolean swap(int sourceSlot, int targetSlot, Class<? extends class_1703> expectedHandlerType) {
        if (!pickup(sourceSlot, expectedHandlerType)) return false;
        if (!pickup(targetSlot, expectedHandlerType)) return false;
        return pickup(sourceSlot, expectedHandlerType);
    }

    public static int findSlot(class_1703 screen, String itemId, int startSlot) {
        for (int i = startSlot; i < screen.field_7761.size(); i++) {
            class_1799 stack = screen.method_7611(i).method_7677();
            if (!stack.method_7960() && ItemIds.fromStack(stack).equals(itemId)) {
                return i;
            }
        }
        return -1;
    }

    public static void closeScreen() {
        ClientThread.run(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p != null) p.method_7346();
        });
        sleep(100);
    }

    static String describeOpenHandler() {
        return ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p == null || p.field_7512 == null) return "none";
            return p.field_7512.getClass().getSimpleName();
        });
    }

    /**
     * Click a slot and verify the result matches expectations.
     * Handles inventory desync by waiting for server acknowledgment.
     *
     * @param slot The slot index to click
     * @param button The mouse button (0=left, 1=right)
     * @param actionType The action type (PICKUP, QUICK_MOVE, etc.)
     * @param expectedItemId Expected item in slot after click (null = empty)
     * @param expectedCount Expected minimum count (0 = any)
     * @return true if click succeeded and verification passed
     */
    static boolean clickAndVerify(int slot, int button, class_1713 actionType,
                                    String expectedItemId, int expectedCount) {
        return clickAndVerify(slot, button, actionType, expectedItemId, expectedCount, null);
    }

    static boolean clickAndVerify(int slot, int button, class_1713 actionType,
                                    String expectedItemId, int expectedCount,
                                    Class<? extends class_1703> expectedHandlerType) {
        boolean clicked = click(slot, button, actionType, expectedHandlerType);
        if (!clicked) return false;
        sleep(100);
        return Boolean.TRUE.equals(ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p == null) return false;
            class_1703 handler = p.field_7512;
            if (!isUsableHandler(handler, slot, expectedHandlerType)) return false;
            class_1799 stack = handler.method_7611(slot).method_7677();
            if (expectedItemId == null) return stack.method_7960();
            String actualId = ItemIds.fromStack(stack);
            return actualId.equals(expectedItemId) && stack.method_7947() >= expectedCount;
        }));
    }

    /**
     * Verify a slot contains the expected item without clicking.
     */
    static boolean verifySlot(int slot, String expectedItemId, int expectedCount) {
        return verifySlot(slot, expectedItemId, expectedCount, null);
    }

    static boolean verifySlot(int slot, String expectedItemId, int expectedCount,
                               Class<? extends class_1703> expectedHandlerType) {
        return Boolean.TRUE.equals(ClientThread.call(() -> {
            class_746 p = class_310.method_1551().field_1724;
            if (p == null) return false;
            class_1703 handler = p.field_7512;
            if (!isUsableHandler(handler, slot, expectedHandlerType)) return false;
            class_1799 stack = handler.method_7611(slot).method_7677();
            if (expectedItemId == null) return stack.method_7960();
            String actualId = ItemIds.fromStack(stack);
            return actualId.equals(expectedItemId) && stack.method_7947() >= expectedCount;
        }));
    }

    /**
     * Click with desync recovery — if verification fails, close/reopen screen and retry.
     */
    static boolean clickWithRecovery(int slot, int button, class_1713 actionType,
                                       String expectedItemId, int expectedCount,
                                       class_2338 workstation) {
        return clickWithRecovery(slot, button, actionType, expectedItemId, expectedCount, workstation, null);
    }

    static boolean clickWithRecovery(int slot, int button, class_1713 actionType,
                                      String expectedItemId, int expectedCount,
                                      class_2338 workstation, Class<? extends class_1703> expectedHandlerType) {
        if (clickAndVerify(slot, button, actionType, expectedItemId, expectedCount, expectedHandlerType)) {
            return true;
        }
        closeScreen();
        sleep(200);
        if (workstation != null) {
            WorldInteractor.openBlock(workstation);
            waitForHandler(expectedHandlerType, 3000);
        }
        return clickAndVerify(slot, button, actionType, expectedItemId, expectedCount, expectedHandlerType);
    }

    /**
     * Pickup with verify: pick up from source, place in target, verify target has item.
     */
    static boolean pickupAndVerify(int sourceSlot, int targetSlot,
                                      String expectedItemId, int expectedCount) {
        return pickupAndVerify(sourceSlot, targetSlot, expectedItemId, expectedCount, null);
    }

    static boolean pickupAndVerify(int sourceSlot, int targetSlot,
                                      String expectedItemId, int expectedCount,
                                      Class<? extends class_1703> expectedHandlerType) {
        if (!click(sourceSlot, 0, class_1713.field_7790, expectedHandlerType)) return false;
        if (!click(targetSlot, 0, class_1713.field_7790, expectedHandlerType)) {
            click(sourceSlot, 0, class_1713.field_7790, expectedHandlerType);
            return false;
        }
        click(sourceSlot, 0, class_1713.field_7790, expectedHandlerType);
        sleep(100);
        return verifySlot(targetSlot, expectedItemId, expectedCount, expectedHandlerType);
    }

    private static boolean isUsableHandler(class_1703 handler, int slot, Class<? extends class_1703> expectedType) {
        if (handler == null) return false;
        if (handler.field_7763 == 0) return false;
        if (expectedType != null && !expectedType.isInstance(handler)) return false;
        return slot >= 0 && slot < handler.field_7761.size();
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
