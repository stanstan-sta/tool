package com.mindcraft.bridge;

import net.minecraft.class_310;

final class DimensionDriver {
    private DimensionDriver() {}

    static String getCurrentDimension() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1687 == null ? "" : c.field_1687.method_27983().method_29177().toString();
        });
    }

    static boolean waitForDimension(String dimensionId, long timeoutMs) {
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            String dim = getCurrentDimension();
            if (dimensionId.equals(dim)) return true;
            sleep(250);
        }
        return false;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
