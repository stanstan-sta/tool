package com.mindcraft.bridge;

import net.minecraft.class_310;

final class DimensionDriver {
    private DimensionDriver() {}

    static String getCurrentDimension() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1687 == null ? "" : c.field_1687.method_27983().method_29177().toString();
        });
    }

    static String normalizeDimension(String dimensionId) {
        if (dimensionId == null) return "";
        String dim = dimensionId.trim().toLowerCase(java.util.Locale.ROOT);
        if (dim.equals("nether") || dim.equals("the_nether") || dim.equals("minecraft:nether")
                || dim.equals("minecraft:the_nether")) {
            return "minecraft:the_nether";
        }
        if (dim.equals("end") || dim.equals("the_end") || dim.equals("minecraft:end")
                || dim.equals("minecraft:the_end")) {
            return "minecraft:the_end";
        }
        if (dim.equals("overworld") || dim.equals("minecraft:overworld")) {
            return "minecraft:overworld";
        }
        return dim;
    }

    static boolean isCurrentDimension(String dimensionId) {
        return normalizeDimension(dimensionId).equals(normalizeDimension(getCurrentDimension()));
    }

    static boolean waitForDimension(String dimensionId, long timeoutMs) {
        String target = normalizeDimension(dimensionId);
        long deadline = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < deadline) {
            String dim = getCurrentDimension();
            if (target.equals(normalizeDimension(dim))) return true;
            sleep(250);
        }
        return false;
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
