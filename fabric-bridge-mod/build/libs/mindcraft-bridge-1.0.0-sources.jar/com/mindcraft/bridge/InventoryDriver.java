package com.mindcraft.bridge;

import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2868;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class InventoryDriver {
    private InventoryDriver() {}

    public static int countItem(class_746 player, String itemId) {
        int total = 0;
        class_1661 inv = player.method_31548();
        String targetStripped = ItemIds.strip(itemId);
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && ItemIds.strip(ItemIds.fromStack(stack)).equals(targetStripped)) {
                total += stack.method_7947();
            }
        }
        return total;
    }

    static boolean hasItem(class_746 player, String itemId) {
        return countItem(player, itemId) > 0;
    }

    public static boolean selectSlot(int slot) {
        if (slot < 0 || slot > 8) return false;
        return ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 p = client.field_1724;
            if (p == null || p.field_3944 == null) return false;
            p.method_31548().method_61496(slot);
            p.field_3944.method_52787(new class_2868(slot));
            return true;
        });
    }

    static int findBestWeaponSlot(class_746 player) {
        class_1661 inv = player.method_31548();
        int bestSlot = -1;
        float bestDamage = -1.0f;
        for (int i = 0; i < 9; i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            String itemId = ItemIds.fromStack(stack).toLowerCase();
            float damage = getMeleeDamage(itemId);
            if (damage > bestDamage) {
                bestDamage = damage;
                bestSlot = i;
            }
        }
        return bestSlot;
    }

    public static boolean equipBestWeapon(class_746 player) {
        int slot = findBestWeaponSlot(player);
        if (slot < 0) return false;
        if (slot == player.method_31548().method_67532()) return true;
        return selectSlot(slot);
    }

    public static int getAttackCooldownMs(class_746 player) {
        class_1799 held = player.method_6047();
        if (held.method_7960()) return 250;
        String name = ItemIds.fromStack(held).toLowerCase();
        if (name.contains("sword")) return 625;
        if (name.contains("axe")) return 1000;
        if (name.contains("pickaxe")) return 833;
        if (name.contains("shovel")) return 1000;
        return 250;
    }

    private static float getMeleeDamage(String itemName) {
        if (itemName.contains("netherite_sword")) return 8.0f;
        if (itemName.contains("diamond_sword")) return 7.0f;
        if (itemName.contains("iron_sword")) return 6.0f;
        if (itemName.contains("stone_sword")) return 5.0f;
        if (itemName.contains("wooden_sword")) return 4.0f;
        if (itemName.contains("golden_sword")) return 4.0f;
        if (itemName.contains("netherite_axe")) return 10.0f;
        if (itemName.contains("diamond_axe")) return 9.0f;
        if (itemName.contains("iron_axe")) return 9.0f;
        if (itemName.contains("stone_axe")) return 9.0f;
        if (itemName.contains("wooden_axe")) return 7.0f;
        if (itemName.contains("golden_axe")) return 7.0f;
        if (itemName.contains("pickaxe")) return 3.0f;
        if (itemName.contains("shovel")) return 2.5f;
        return 1.0f;
    }
}
