package com.mindcraft.bridge;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_310;

final class StructureValidator {
    private StructureValidator() {}

    record BlockMismatch(class_2338 pos, String expected, String actual) {}

    static List<BlockMismatch> compare(List<String> paletteIds, short[] blocks,
                                       int width, int height, int length,
                                       class_2338 origin) {
        return ClientThread.call(() -> {
            List<BlockMismatch> mismatches = new ArrayList<>();
            class_310 client = class_310.method_1551();
            if (client.field_1687 == null) return mismatches;

            class_2338.class_2339 mutable = new class_2338.class_2339();
            for (int y = 0; y < height; y++) {
                for (int z = 0; z < length; z++) {
                    for (int x = 0; x < width; x++) {
                        int idx = (y * length + z) * width + x;
                        int paletteIdx = blocks[idx] & 0xFFFF;
                        if (paletteIdx < 0 || paletteIdx >= paletteIds.size()) continue;
                        String expected = paletteIds.get(paletteIdx);
                        if (expected == null) continue;
                        String stripped = ItemIds.strip(expected);
                        if ("air".equals(stripped) || "cave_air".equals(stripped)
                                || "void_air".equals(stripped)) continue;

                        mutable.method_10103(origin.method_10263() + x, origin.method_10264() + y, origin.method_10260() + z);
                        String actual = ItemIds.fromBlock(
                                client.field_1687.method_8320(mutable).method_26204());
                        if (!actual.equals(expected)) {
                            mismatches.add(new BlockMismatch(
                                    mutable.method_10062(), expected, actual));
                        }
                    }
                }
            }
            return mismatches;
        });
    }
}
