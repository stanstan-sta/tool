package com.mindcraft.bridge.workers.gathering;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_1707;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LootWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");
    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = ctx.actionType() != null ? "#" + ctx.actionType() : "#loot";
        try {
            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            String targetId = CommandExecutor.extractJsonString(actionJson, "target");
            if (targetId == null) {
                // Sub-actions derive their identity from the registered type
                String actionType = ctx.actionType();
                if (actionType != null && !actionType.equals("loot")) {
                    targetId = actionType;
                }
            }
            if (targetId == null) return WorkerResult.failure("loot: missing target");

            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("loot: not connected");
            }

            String containerBlock = null;
            for (String candidate : new String[]{"minecraft:chest", "minecraft:barrel", "minecraft:trapped_chest"}) {
                class_2338 found = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    return WorkstationFinder.findNearest(c.field_1687, c.field_1724, candidate, 16);
                });
                if (found != null) {
                    containerBlock = candidate;
                    if (!WorldInteractor.openBlock(found)) {
                        CommandExecutor.sleep(200);
                        continue;
                    }
                    break;
                }
            }
            if (containerBlock == null) {
                return WorkerResult.failure("loot: no container found nearby");
            }

            if (!ScreenDriver.waitForHandler(class_1707.class, 5000)) {
                ScreenDriver.closeScreen();
                return WorkerResult.failure("loot: container screen did not open");
            }

            String normalized = ItemIds.normalize(targetId);
            boolean found = false;
            for (int attempt = 0; attempt < 50; attempt++) {
                if (ctx.isCancelled().get()) break;
                int slot = ClientThread.call(() -> {
                    class_746 p = class_310.method_1551().field_1724;
                    if (p == null || !(p.field_7512 instanceof class_1707 handler)) return -1;
                    for (int i = 0; i < handler.method_7629().method_5439(); i++) {
                        class_1799 stack = handler.method_7629().method_5438(i);
                        if (!stack.method_7960() && ItemIds.fromStack(stack).equals(normalized)) return i;
                    }
                    return -1;
                });
                if (slot >= 0) {
                    CommandExecutor.sleep(50); // Wait for slot state sync before moving
                    ScreenDriver.quickMove(slot);
                    found = true;
                    CommandExecutor.sleep(200);
                    break;
                }
                CommandExecutor.sleep(100);
            }

            ScreenDriver.closeScreen();
            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (found) {
                ctx.taskQueue().completeActiveIf(command);
                return WorkerResult.success("looted " + normalized);
            } else {
                return WorkerResult.failure("loot: " + normalized + " not found in container");
            }
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
}
