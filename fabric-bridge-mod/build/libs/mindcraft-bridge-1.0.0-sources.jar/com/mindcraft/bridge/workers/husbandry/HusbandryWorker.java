package com.mindcraft.bridge.workers.husbandry;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_10730;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1428;
import net.minecraft.class_1429;
import net.minecraft.class_1451;
import net.minecraft.class_1452;
import net.minecraft.class_1453;
import net.minecraft.class_1472;
import net.minecraft.class_1493;
import net.minecraft.class_1496;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.entity.passive.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class HusbandryWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");

    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = ctx.actionType() != null ? "#" + ctx.actionType() : "#husbandry";
        try {
            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("husbandry: not connected");
            }

            String action = CommandExecutor.extractJsonString(actionJson, "action");
            if (action == null) action = ctx.actionType();
            if (action == null) action = "shear";

            WorkerResult result = switch (action) {
                case "shear" -> executeShear(actionJson, ctx);
                case "milk" -> executeMilk(actionJson, ctx);
                case "breed" -> executeBreed(actionJson, ctx);
                case "tame" -> executeTame(actionJson, ctx);
                default -> WorkerResult.failure("husbandry: unknown action " + action);
            };
            if (result.ok()) {
                ctx.taskQueue().completeActiveIf(command);
            }
            return result;
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }

    private WorkerResult executeShear(String actionJson, WorkerContext ctx) {
        class_1297 target = findNearestSheep();
        if (target == null) {
            return WorkerResult.failure("husbandry: no sheep nearby");
        }

        if (ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1724 == null || InventoryDriver.countItem(c.field_1724, "minecraft:shears") <= 0;
        })) {
            return WorkerResult.failure("husbandry: no shears");
        }

        int slot = findAndSelectItem("minecraft:shears");
        if (slot < 0) {
            return WorkerResult.failure("husbandry: no shears in hotbar");
        }

        boolean success = interactWithEntity(target.method_5628());
        if (success) {
            CommandExecutor.sendBridgeMessage("[Bridge] Husbandry: sheared sheep");
            return WorkerResult.success("husbandry: sheared sheep");
        } else {
            return WorkerResult.failure("husbandry: failed to shear");
        }
    }

    private WorkerResult executeMilk(String actionJson, WorkerContext ctx) {
        class_1297 target = findNearestCow();
        if (target == null) {
            return WorkerResult.failure("husbandry: no cow nearby");
        }

        if (ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1724 == null || InventoryDriver.countItem(c.field_1724, "minecraft:bucket") <= 0;
        })) {
            return WorkerResult.failure("husbandry: no bucket");
        }

        int slot = findAndSelectItem("minecraft:bucket");
        if (slot < 0) {
            return WorkerResult.failure("husbandry: no bucket in hotbar");
        }

        CommandExecutor.sleepQuietly(200);

        boolean success = interactWithEntity(target.method_5628());
        if (success) {
            CommandExecutor.sendBridgeMessage("[Bridge] Husbandry: milked cow");
            return WorkerResult.success("husbandry: milked cow");
        } else {
            return WorkerResult.failure("husbandry: failed to milk");
        }
    }

    private WorkerResult executeBreed(String actionJson, WorkerContext ctx) {
        List<class_1297> animals = findNearbyAnimals();
        if (animals.size() < 2) {
            return WorkerResult.failure("husbandry: need at least 2 animals");
        }

        class_1297 animal1 = animals.get(0);
        class_1297 animal2 = animals.get(1);

        String breedingItem = getBreedingItem(animal1);
        if (breedingItem == null) {
            return WorkerResult.failure("husbandry: unknown animal type");
        }

        if (ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1724 == null || InventoryDriver.countItem(c.field_1724, breedingItem) < 2;
        })) {
            return WorkerResult.failure("husbandry: need 2 " + breedingItem + " for breeding");
        }

        int slot = findAndSelectItem(breedingItem);
        if (slot < 0) {
            return WorkerResult.failure("husbandry: no breeding item in hotbar");
        }

        CommandExecutor.sleepQuietly(200);

        boolean fed1 = interactWithEntity(animal1.method_5628());
        if (!fed1) {
            return WorkerResult.failure("husbandry: failed to feed first animal");
        }

        CommandExecutor.sleepQuietly(500);

        boolean fed2 = interactWithEntity(animal2.method_5628());
        if (fed2) {
            CommandExecutor.sendBridgeMessage("[Bridge] Husbandry: bred animals");
            return WorkerResult.success("husbandry: bred animals");
        } else {
            return WorkerResult.failure("husbandry: failed to feed second animal");
        }
    }

    private WorkerResult executeTame(String actionJson, WorkerContext ctx) {
        class_1297 target = findNearestTameable();
        if (target == null) {
            return WorkerResult.failure("husbandry: no tameable animal nearby");
        }

        String tamingItem = getTamingItem(target);
        if (tamingItem == null) {
            return WorkerResult.failure("husbandry: unknown tameable type");
        }

        if (ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1724 == null || InventoryDriver.countItem(c.field_1724, tamingItem) <= 0;
        })) {
            return WorkerResult.failure("husbandry: no " + tamingItem + " for taming");
        }

        int slot = findAndSelectItem(tamingItem);
        if (slot < 0) {
            return WorkerResult.failure("husbandry: no taming item in hotbar");
        }

        for (int i = 0; i < 10; i++) {
            if (ctx.isCancelled().get()) {
                return WorkerResult.failure("husbandry: cancelled");
            }

            boolean dead = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null || c.field_1724.method_29504() || c.field_1724.method_6032() <= 0;
            });
            if (dead) {
                return WorkerResult.failure("husbandry: player died");
            }

            CommandExecutor.sleepQuietly(300);

            boolean success = interactWithEntity(target.method_5628());
            if (success) {
                CommandExecutor.sendBridgeMessage("[Bridge] Husbandry: tamed animal");
                return WorkerResult.success("husbandry: tamed animal");
            }
        }

        return WorkerResult.failure("husbandry: failed to tame after attempts");
    }

    private boolean interactWithEntity(int entityId) {
        boolean result = Boolean.TRUE.equals(ClientThread.call(() -> {
            class_310 client = class_310.method_1551();
            class_746 player = client.field_1724;
            if (player == null || client.field_1761 == null || client.field_1687 == null) return false;
            class_1297 entity = client.field_1687.method_8469(entityId);
            if (entity == null) return false;
            client.field_1761.method_2905(player, entity, class_1268.field_5808);
            return true;
        }));
        CommandExecutor.sleepQuietly(100); // Wait for server acknowledgment
        return result;
    }

    private class_1297 findNearestSheep() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(16),
                e -> e instanceof class_1472 sheep && sheep.method_5805()
            ).stream().findFirst().orElse(null);
        });
    }

    private class_1297 findNearestCow() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(16),
                e -> e instanceof class_10730 cow && cow.method_5805()
            ).stream().findFirst().orElse(null);
        });
    }

    private class_1297 findNearestTameable() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(16),
                e -> e.method_5805() && (e instanceof class_1321 || e instanceof class_1496)
            ).stream().findFirst().orElse(null);
        });
    }

    private List<class_1297> findNearbyAnimals() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return List.of();
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(16),
                e -> e.method_5805() && e instanceof class_1429
            );
        });
    }

    private String getBreedingItem(class_1297 entity) {
        if (entity instanceof class_10730) return "minecraft:wheat";
        if (entity instanceof class_1472) return "minecraft:wheat";
        if (entity instanceof class_1452) return "minecraft:carrot";
        if (entity instanceof class_1428) return "minecraft:wheat_seeds";
        if (entity instanceof class_1493) return "minecraft:bone";
        if (entity instanceof class_1451) return "minecraft:raw_cod";
        return null;
    }

    private String getTamingItem(class_1297 entity) {
        if (entity instanceof class_1493) return "minecraft:bone";
        if (entity instanceof class_1451) return "minecraft:raw_cod";
        if (entity instanceof class_1453) return "minecraft:wheat_seeds";
        if (entity instanceof class_1496) return "minecraft:golden_apple";
        return null;
    }

    private int findAndSelectItem(String itemId) {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1724 == null) return -1;
            for (int i = 0; i < 9; i++) {
                var stack = c.field_1724.method_31548().method_5438(i);
                if (!stack.method_7960() && ItemIds.fromStack(stack).equals(itemId)) {
                    InventoryDriver.selectSlot(i);
                    return i;
                }
            }
            return -1;
        });
    }

    @Override
    public boolean requiresThread() {
        return true;
    }
}
