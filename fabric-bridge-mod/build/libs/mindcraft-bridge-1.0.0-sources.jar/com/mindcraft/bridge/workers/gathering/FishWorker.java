package com.mindcraft.bridge.workers.gathering;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FishWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");
    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = "#fish";
        try {
            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            String countStr = CommandExecutor.extractJsonPrimitive(actionJson, "count");
            int targetCount = 1;
            if (countStr != null) {
                try { targetCount = Math.max(1, Integer.parseInt(countStr)); } catch (NumberFormatException ignored) {}
            }

            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("fish: not connected");
            }

            int rodSlot = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                if (c.field_1724 == null) return -1;
                class_1661 inv = c.field_1724.method_31548();
                for (int i = 0; i < 9; i++) {
                    class_1799 stack = inv.method_5438(i);
                    if (!stack.method_7960() && ItemIds.fromStack(stack).equals("minecraft:fishing_rod")) {
                        return i;
                    }
                }
                return -1;
            });
            if (rodSlot < 0) {
                return WorkerResult.failure("fish: no fishing rod in hotbar");
            }

            class_2338 water = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                if (c.field_1724 == null || c.field_1687 == null) return null;
                class_2338.class_2339 mutable = new class_2338.class_2339();
                class_2338 playerPos = c.field_1724.method_24515();
                for (int dx = -4; dx <= 4; dx++) {
                    for (int dz = -4; dz <= 4; dz++) {
                        for (int dy = -2; dy <= 2; dy++) {
                            mutable.method_10103(playerPos.method_10263() + dx, playerPos.method_10264() + dy, playerPos.method_10260() + dz);
                            if (c.field_1687.method_8320(mutable).method_26227().method_15767(net.minecraft.class_3486.field_15517)) {
                                return mutable.method_10062();
                            }
                        }
                    }
                }
                return null;
            });
            if (water == null) {
                return WorkerResult.failure("fish: no water found nearby");
            }

            InventoryDriver.selectSlot(rodSlot);
            CommandExecutor.sleep(200);

            int caught = 0;
            for (int attempt = 0; attempt < targetCount * 5 && caught < targetCount; attempt++) {
                if (ctx.isCancelled().get()) break;

                ClientThread.run(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 != null && c.field_1761 != null) {
                        c.field_1761.method_2919(c.field_1724, class_1268.field_5808);
                    }
                });
                CommandExecutor.sleep(500);

                // Wait for bite by checking bobber entity for movement
                long biteDeadline = System.currentTimeMillis() + 30_000L;
                boolean bobberMoved = false;
                int lastBobberY = -1;
                while (System.currentTimeMillis() < biteDeadline && !bobberMoved) {
                    if (ctx.isCancelled().get()) break;
                    
                    // Check for fishing bobber entity and detect bite via Y movement
                    Integer bobberY = ClientThread.call(() -> {
                        class_310 c = class_310.method_1551();
                        if (c.field_1724 == null || c.field_1687 == null) return null;
                        // Find fishing bobber owned by player
                        var entities = c.field_1687.method_8390(
                            net.minecraft.class_1536.class,
                            c.field_1724.method_5829().method_1014(32),
                            e -> e.method_24921() == c.field_1724
                        );
                        if (entities.isEmpty()) return null;
                        return (int) entities.get(0).method_23318();
                    });
                    
                    if (bobberY != null) {
                        if (lastBobberY >= 0 && bobberY != lastBobberY) {
                            // Bobber moved — fish bit!
                            bobberMoved = true;
                        }
                        lastBobberY = bobberY;
                    }
                    
                    CommandExecutor.sleep(200);
                }
                
                if (ctx.isCancelled().get()) break;
                
                // Reel in (right-click again to catch)
                if (bobberMoved) {
                    ClientThread.run(() -> {
                        class_310 c = class_310.method_1551();
                        if (c.field_1724 != null && c.field_1761 != null) {
                            c.field_1761.method_2919(c.field_1724, class_1268.field_5808);
                        }
                    });
                    CommandExecutor.sleep(500);
                    caught++;
                }
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (caught >= targetCount) {
                ctx.taskQueue().completeActiveIf(command);
                return WorkerResult.success("fished " + caught);
            } else {
                return WorkerResult.failure("fish: caught " + caught + "/" + targetCount);
            }
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
}
