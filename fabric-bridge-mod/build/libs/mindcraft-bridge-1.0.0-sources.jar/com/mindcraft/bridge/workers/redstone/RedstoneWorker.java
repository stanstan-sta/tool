package com.mindcraft.bridge.workers.redstone;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RedstoneWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");
    
    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = ctx.actionType() != null ? "#" + ctx.actionType() : "#redstone";
        try {
            boolean connected = ClientThread.call(() -> {
                var c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("redstone: not connected");
            }
            
            String action = extractAction(actionJson);
            
            WorkerResult result = switch (action) {
                case "tune_repeater" -> executeTuneRepeater(actionJson, ctx);
                case "read_comparator" -> executeReadComparator(actionJson, ctx);
                case "place_redstone" -> executePlaceRedstone(actionJson, ctx);
                default -> WorkerResult.failure("redstone: unknown action " + action);
            };
            if (result.ok()) {
                ctx.taskQueue().completeActiveIf(command);
            }
            return result;
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
    
    private WorkerResult executeTuneRepeater(String actionJson, WorkerContext ctx) {
        class_2338 pos = extractPosition(actionJson);
        if (pos == null) {
            return WorkerResult.failure("redstone: missing position");
        }
        
        int delay = extractInt(actionJson, "delay", 1);
        if (delay < 1 || delay > 4) {
            return WorkerResult.failure("redstone: delay must be 1-4");
        }
        
        class_2680 state = ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1687 == null ? null : c.field_1687.method_8320(pos);
        });
        
        if (!(state.method_26204() instanceof class_2462)) {
            return WorkerResult.failure("redstone: not a repeater at position");
        }
        
        int currentDelay = state.method_11654(class_2741.field_12494);
        
        int clicksNeeded = (delay - currentDelay + 4) % 4;
        
        for (int i = 0; i < clicksNeeded; i++) {
            WorldInteractor.interactBlock(pos, class_2350.field_11036);
        }
        
        return WorkerResult.success("redstone: repeater tuned to " + delay + " ticks");
    }
    
    private WorkerResult executeReadComparator(String actionJson, WorkerContext ctx) {
        class_2338 pos = extractPosition(actionJson);
        if (pos == null) {
            return WorkerResult.failure("redstone: missing position");
        }
        
        int output = ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null) return -1;
            class_2680 state = c.field_1687.method_8320(pos);
            if (state.method_26204() instanceof class_2286) {
                return state.method_11654(class_2741.field_12511);
            }
            return -1;
        });
        
        if (output < 0) {
            return WorkerResult.failure("redstone: not a comparator at position");
        }
        
        return WorkerResult.success("redstone: comparator output = " + output);
    }
    
    private WorkerResult executePlaceRedstone(String actionJson, WorkerContext ctx) {
        class_2338 pos = extractPosition(actionJson);
        if (pos == null) {
            return WorkerResult.failure("redstone: missing position");
        }
        
        String blockType = extractString(actionJson, "block", "redstone_wire");
        
        boolean success = WorldInteractor.placeBlock(pos, class_2350.field_11036);
        
        if (success) {
            return WorkerResult.success("redstone: placed " + blockType);
        } else {
            return WorkerResult.failure("redstone: failed to place");
        }
    }
    
    private class_2338 extractPosition(String json) {
        int x = extractInt(json, "x", 0);
        int y = extractInt(json, "y", 0);
        int z = extractInt(json, "z", 0);
        return new class_2338(x, y, z);
    }
    
    private int extractInt(String json, String key, int defaultVal) {
        int idx = json.indexOf("\"" + key + "\"");
        if (idx < 0) return defaultVal;
        int start = json.indexOf(":", idx) + 1;
        int end = json.indexOf(",", start);
        if (end < 0) end = json.indexOf("}", start);
        try {
            return Integer.parseInt(json.substring(start, end).trim());
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }
    
    private String extractString(String json, String key, String defaultVal) {
        int idx = json.indexOf("\"" + key + "\"");
        if (idx < 0) return defaultVal;
        int start = json.indexOf("\"", idx + key.length() + 2) + 1;
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }
    
    private String extractAction(String json) {
        int idx = json.indexOf("\"action\"");
        if (idx < 0) return "";
        int start = json.indexOf("\"", idx + 8) + 1;
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }
    
    @Override
    public boolean requiresThread() {
        return true;
    }
}
