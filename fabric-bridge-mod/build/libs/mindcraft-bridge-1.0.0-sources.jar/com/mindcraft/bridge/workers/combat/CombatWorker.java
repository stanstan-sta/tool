package com.mindcraft.bridge.workers.combat;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.*;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

public class CombatWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");

    private enum CombatState { SEARCHING, APPROACHING, ENGAGING, LOOTING, DONE }

    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = "#combat";
        try {
            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                CommandExecutor.sendBridgeMessage("[Bridge] Combat: not connected");
                return WorkerResult.failure("combat: not connected");
            }
            class_310 client = class_310.method_1551();
            class_746 player = ClientThread.call(() -> class_310.method_1551().field_1724);

            String targetTypeRaw = CommandExecutor.extractJsonString(actionJson, "target_type");
            String maxDistStr = CommandExecutor.extractJsonPrimitive(actionJson, "max_distance");
            String retreatHpStr = CommandExecutor.extractJsonPrimitive(actionJson, "retreat_hp");
            String countStr = CommandExecutor.extractJsonPrimitive(actionJson, "count");
            String searchTimeStr = CommandExecutor.extractJsonPrimitive(actionJson, "search_time_s");
            String untilItemsJson = CommandExecutor.extractJsonObject(actionJson, "until_items");

            final double maxDistance;
            if (maxDistStr != null) {
                double parsed;
                try { parsed = Double.parseDouble(maxDistStr); } catch (NumberFormatException ignored) { parsed = 48.0; }
                maxDistance = parsed;
            } else {
                maxDistance = 48.0;
            }
            double retreatHp = 10.0;
            if (retreatHpStr != null) {
                try { retreatHp = Double.parseDouble(retreatHpStr); } catch (NumberFormatException ignored) {}
            }
            int targetCount = 1;
            if (countStr != null) {
                try { targetCount = Math.max(1, Integer.parseInt(countStr)); } catch (NumberFormatException ignored) {}
            }
            int searchTimeS = 30;
            if (searchTimeStr != null) {
                try { searchTimeS = Math.max(0, Math.min(120, Integer.parseInt(searchTimeStr))); } catch (NumberFormatException ignored) {}
            }

            Map<String, Integer> untilItems = new HashMap<>();
            boolean useUntilItems = untilItemsJson != null && !untilItemsJson.isBlank();
            if (useUntilItems) {
                String inner = untilItemsJson.trim();
                if (inner.startsWith("{")) inner = inner.substring(1);
                if (inner.endsWith("}")) inner = inner.substring(0, inner.length() - 1);
                for (String pair : inner.split(",")) {
                    String[] kv = pair.split(":", 2);
                    if (kv.length == 2) {
                        String item = kv[0].trim().replace("\"", "");
                        String count = kv[1].trim().replace("\"", "");
                        try {
                            untilItems.put(item, Integer.parseInt(count));
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }

            int killsRemaining = targetCount;
            int totalAttempts = 0;
            int maxAttempts = targetCount * 3;
            if (useUntilItems && maxAttempts < 30) {
                maxAttempts = 30;
            }

            CombatState state = CombatState.SEARCHING;
            long searchDeadline = System.currentTimeMillis() + (searchTimeS * 1000L);
            class_1297 currentTarget = null;
            class_1297 huntTarget = null;
            boolean isSafetyKill = false;
            AtomicLong lastHitTimestamp = new AtomicLong(0);
            class_243 lastTargetPos = null;
            long retargetTimer = 0;
            class_2338 lastGotoTarget = null;
            boolean announcedSearch = false;

            boolean hadWeapon = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && InventoryDriver.equipBestWeapon(c.field_1724);
            });
            if (!hadWeapon) {
                CommandExecutor.sendBridgeMessage("[Bridge] Combat: no weapon in hotbar — punching with fist");
            }

            while (state != CombatState.DONE && totalAttempts < maxAttempts) {
                player = ClientThread.call(() -> class_310.method_1551().field_1724);
                boolean stillConnected = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    return c.field_1724 != null && c.field_1687 != null;
                });
                if (!stillConnected) {
                    CommandExecutor.sendBridgeMessage("[Bridge] Combat: not connected");
                    return WorkerResult.failure("combat: not connected");
                }

                boolean isDead = ClientThread.call(() -> {
                    class_746 p = class_310.method_1551().field_1724;
                    return p != null && (p.method_29504() || p.method_6032() <= 0);
                });
                if (isDead) {
                    CommandExecutor.sendBridgeMessage("[Bridge] Combat: player died");
                    return WorkerResult.failure("combat: player died");
                }
                float health = ClientThread.call(() -> {
                    class_746 p = class_310.method_1551().field_1724;
                    return p == null ? 0f : p.method_6032();
                });
                if (health <= retreatHp) {
                    CommandExecutor.sendBridgeMessage("[Bridge] Combat: retreating — HP too low");
                    return WorkerResult.failure("combat: retreating");
                }

                switch (state) {
                    case SEARCHING: {
                        lastGotoTarget = null;
                        if (useUntilItems) {
                            boolean allMet = true;
                            for (Map.Entry<String, Integer> entry : untilItems.entrySet()) {
                                int have = ClientThread.call(() -> {
                                    class_310 c = class_310.method_1551();
                                    return c.field_1724 == null ? 0 : InventoryDriver.countItem(c.field_1724, ItemIds.normalize(entry.getKey()));
                                });
                                if (have < entry.getValue()) {
                                    allMet = false;
                                    break;
                                }
                            }
                            if (allMet) {
                                CommandExecutor.sendBridgeMessage("[Bridge] Hunt: all item goals met");
                                state = CombatState.DONE;
                                continue;
                            }
                        } else if (killsRemaining <= 0) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: kill count reached");
                            state = CombatState.DONE;
                            continue;
                        }

                        currentTarget = ClientThread.call(() -> {
                            class_310 c = class_310.method_1551();
                            return c.field_1724 == null ? null : CommandExecutor.findNearestHostileOfType(c, c.field_1724, targetTypeRaw, maxDistance);
                        });
                        if (currentTarget != null) {
                            final class_1297 currentTargetForName = currentTarget;
                            String targetName = ClientThread.call(() -> currentTargetForName.method_5864().toString());
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: found " + CommandExecutor.normalizeEntityTypeName(targetName));
                            final class_1297 currentTargetForPos = currentTarget;
                            lastTargetPos = ClientThread.call(() -> new class_243(currentTargetForPos.method_23317(), currentTargetForPos.method_23318(), currentTargetForPos.method_23321()));
                            state = CombatState.APPROACHING;
                            continue;
                        }

                        if (searchTimeS <= 0 || System.currentTimeMillis() >= searchDeadline) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: no " + (targetTypeRaw != null ? targetTypeRaw : "hostile") + " found after " + searchTimeS + "s");
                            state = CombatState.DONE;
                            continue;
                        }

                        if (!announcedSearch) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: searching via #explore ...");
                            announcedSearch = true;
                        }
                        TaskQueue.getInstance().cancelAll();
                        CommandExecutor.sleepQuietly(150);
                        TaskQueue.getInstance().enqueue("#explore");

                        long exploreDeadline = System.currentTimeMillis() + 8000;
                        boolean found = false;
                        while (System.currentTimeMillis() < exploreDeadline) {
                            player = ClientThread.call(() -> class_310.method_1551().field_1724);
                            boolean exploreDisconnected = ClientThread.call(() -> {
                                class_310 c = class_310.method_1551();
                                return c.field_1724 == null || c.field_1687 == null;
                            });
                            if (exploreDisconnected) return WorkerResult.failure("combat: disconnected during explore");
                            boolean exploreDead = ClientThread.call(() -> {
                                class_746 p = class_310.method_1551().field_1724;
                                return p != null && (p.method_29504() || p.method_6032() <= 0);
                            });
                            if (exploreDead) {
                                CommandExecutor.sendBridgeMessage("[Bridge] Combat: player died");
                                return WorkerResult.failure("combat: player died");
                            }
                            float exploreHealth = ClientThread.call(() -> {
                                class_746 p = class_310.method_1551().field_1724;
                                return p == null ? 0f : p.method_6032();
                            });
                            if (exploreHealth <= retreatHp) {
                                CommandExecutor.sendBridgeMessage("[Bridge] Combat: retreating — HP too low");
                                return WorkerResult.failure("combat: retreating");
                            }

                            currentTarget = ClientThread.call(() -> {
                                class_310 c = class_310.method_1551();
                                return c.field_1724 == null ? null : CommandExecutor.findNearestHostileOfType(c, c.field_1724, targetTypeRaw, maxDistance);
                            });
                            if (currentTarget != null) {
                                TaskQueue.getInstance().cancelAll();
                                CommandExecutor.sleepQuietly(150);
                                final class_1297 exploreTargetForName = currentTarget;
                                String targetName = ClientThread.call(() -> exploreTargetForName.method_5864().toString());
                                CommandExecutor.sendBridgeMessage("[Bridge] Hunt: found " + CommandExecutor.normalizeEntityTypeName(targetName) + " during explore");
                                final class_1297 exploreTargetForPos = currentTarget;
                                lastTargetPos = ClientThread.call(() -> new class_243(exploreTargetForPos.method_23317(), exploreTargetForPos.method_23318(), exploreTargetForPos.method_23321()));
                                state = CombatState.APPROACHING;
                                found = true;
                                break;
                            }
                            CommandExecutor.sleepQuietly(500);
                        }
                        if (!found) {
                            TaskQueue.getInstance().cancelAll();
                            CommandExecutor.sleepQuietly(150);
                        }
                        continue;
                    }

                    case APPROACHING: {
                        announcedSearch = false;
                        final class_1297 approachTarget = currentTarget;
                        boolean targetLost = currentTarget == null || ClientThread.call(() -> approachTarget.method_31481() || !approachTarget.method_5805());
                        if (targetLost) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: target lost during approach");
                            state = CombatState.SEARCHING;
                            continue;
                        }

                        final class_1297 approachTargetForDist = currentTarget;
                        final class_746 approachPlayer = player;
                        double dist = ClientThread.call(() -> approachPlayer.method_5858(approachTargetForDist));
                        if (dist <= 16.0) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: target in melee range, engaging");
                            TaskQueue.getInstance().cancelAll();
                            CommandExecutor.sleepQuietly(200);
                            state = CombatState.ENGAGING;
                            retargetTimer = System.currentTimeMillis();
                            continue;
                        }

                        final class_1297 ctForBlock = currentTarget;
                        class_2338 currentTargetBlock = ClientThread.call(() -> new class_2338(
                                (int) Math.floor(ctForBlock.method_23317()),
                                (int) Math.floor(ctForBlock.method_23318()),
                                (int) Math.floor(ctForBlock.method_23321())
                        ));
                        if (lastGotoTarget == null || !lastGotoTarget.equals(currentTargetBlock)) {
                            TaskQueue.getInstance().cancelAll();
                            CommandExecutor.sleepQuietly(100);
                            TaskQueue.getInstance().enqueue(
                                    "#goto " + currentTargetBlock.method_10263() + " " +
                                            currentTargetBlock.method_10264() + " " +
                                            currentTargetBlock.method_10260()
                            );
                            lastGotoTarget = currentTargetBlock;
                        }

                        CommandExecutor.sleepQuietly(500);
                        continue;
                    }

                    case ENGAGING: {
                        announcedSearch = false;
                        lastGotoTarget = null;
                        ClientThread.run(() -> {
                            class_310 c = class_310.method_1551();
                            if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
                        });

                        final class_1297 engageTargetDead = currentTarget;
                        boolean targetDead = currentTarget == null || ClientThread.call(() -> engageTargetDead.method_31481() || !engageTargetDead.method_5805());
                        if (targetDead) {
                            boolean recentHit = (System.currentTimeMillis() - lastHitTimestamp.get()) < 2000;
                            if (isSafetyKill) {
                                CommandExecutor.sendBridgeMessage("[Bridge] Hunt: safety-killed threat, back to hunt");
                                isSafetyKill = false;
                                currentTarget = huntTarget;
                                huntTarget = null;
                                final class_1297 huntTargetAlive = currentTarget;
                                if (currentTarget != null && ClientThread.call(() -> huntTargetAlive.method_5805())) {
                                    state = CombatState.APPROACHING;
                                } else {
                                    state = CombatState.SEARCHING;
                                }
                                continue;
                            }
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: target killed");
                            totalAttempts++;
                            if (!useUntilItems && recentHit) {
                                killsRemaining--;
                            }
                            if (currentTarget != null) {
                                final class_1297 lastTargetForPos = currentTarget;
                                lastTargetPos = ClientThread.call(() -> new class_243(lastTargetForPos.method_23317(), lastTargetForPos.method_23318(), lastTargetForPos.method_23321()));
                            }
                            state = CombatState.LOOTING;
                            continue;
                        }

                        final class_1297 engageTargetForDist = currentTarget;
                        final class_746 engagePlayer = player;
                        double dist = ClientThread.call(() -> engagePlayer.method_5858(engageTargetForDist));
                        if (dist > 36.0) {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: target moved away, re-approaching");
                            lastGotoTarget = null;
                            state = CombatState.APPROACHING;
                            continue;
                        }

                        if (System.currentTimeMillis() - retargetTimer >= 2000) {
                            retargetTimer = System.currentTimeMillis();
                            class_1297 threat = ClientThread.call(() -> {
                                class_310 c = class_310.method_1551();
                                return c.field_1724 == null ? null : CommandExecutor.findClosestHostile(c, c.field_1724, 4.0);
                            });
                            if (threat != null && threat != currentTarget) {
                                final class_746 threatPlayer = player;
                                final class_1297 threatEntity = threat;
                                double distThreat = ClientThread.call(() -> threatPlayer.method_5858(threatEntity));
                                final class_746 currentPlayer = player;
                                final class_1297 currentTargetForComp = currentTarget;
                                double distCurrent = ClientThread.call(() -> currentPlayer.method_5858(currentTargetForComp));
                                if (distThreat < distCurrent) {
                                    if (!isSafetyKill) {
                                        huntTarget = currentTarget;
                                        isSafetyKill = true;
                                    }
                                    currentTarget = threat;
                                }
                            }
                        }

                        final class_746 fp = player;
                        final class_1297 t = currentTarget;
                        final AtomicLong hitStamp = lastHitTimestamp;
                        ClientThread.run(() -> {
                            CommandExecutor.lookAtEntity(fp, t);
                            if (client.field_1761 != null) {
                                client.field_1761.method_2918(fp, t);
                                fp.method_6104(class_1268.field_5808);
                                hitStamp.set(System.currentTimeMillis());
                            }
                        });

                        int cooldownMs = ClientThread.call(() -> {
                            class_310 c = class_310.method_1551();
                            return c.field_1724 == null ? 500 : InventoryDriver.getAttackCooldownMs(c.field_1724);
                        });
                        CommandExecutor.sleepQuietly(cooldownMs);
                        continue;
                    }

                    case LOOTING: {
                        announcedSearch = false;
                        lastGotoTarget = null;
                        CommandExecutor.sendBridgeMessage("[Bridge] Hunt: looting drops ...");
                        CommandExecutor.sleepQuietly(2500);

                        if (lastTargetPos != null) {
                            final class_746 lootingPlayer = player;
                            class_243 playerPos = ClientThread.call(() -> new class_243(lootingPlayer.method_23317(), lootingPlayer.method_23318(), lootingPlayer.method_23321()));
                            class_243 toTarget = lastTargetPos.method_1020(playerPos);
                            double len = toTarget.method_1033();
                            if (len > 0.1) {
                                class_243 movePos = playerPos.method_1019(toTarget.method_1029().method_1021(Math.min(len, 2.0)));
                                int mx = (int) Math.floor(movePos.field_1352);
                                int my = (int) Math.floor(movePos.field_1351);
                                int mz = (int) Math.floor(movePos.field_1350);
                                TaskQueue.getInstance().cancelAll();
                                CommandExecutor.sleepQuietly(150);
                                TaskQueue.getInstance().enqueue("#goto " + mx + " " + my + " " + mz);
                                CommandExecutor.waitForActiveTaskComplete(10_000L);
                                TaskQueue.getInstance().cancelAll();
                                CommandExecutor.sleepQuietly(150);
                            }
                        }

                        long lootDeadline = System.currentTimeMillis() + 10_000;
                        boolean itemsMet = false;
                        while (System.currentTimeMillis() < lootDeadline) {
                            player = ClientThread.call(() -> class_310.method_1551().field_1724);
                            if (player == null) break;
                            if (useUntilItems) {
                                boolean allMet = true;
                                for (Map.Entry<String, Integer> entry : untilItems.entrySet()) {
                                    int have = ClientThread.call(() -> {
                                        class_310 c = class_310.method_1551();
                                        return c.field_1724 == null ? 0 : InventoryDriver.countItem(c.field_1724, ItemIds.normalize(entry.getKey()));
                                    });
                                    if (have < entry.getValue()) {
                                        allMet = false;
                                        break;
                                    }
                                }
                                if (allMet) {
                                    itemsMet = true;
                                    break;
                                }
                            } else {
                                itemsMet = true;
                                break;
                            }
                            CommandExecutor.sleepQuietly(500);
                        }

                        if (itemsMet) {
                            if (useUntilItems) {
                                CommandExecutor.sendBridgeMessage("[Bridge] Hunt: all item goals met");
                            }
                            state = CombatState.DONE;
                        } else {
                            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: need more kills, returning to search");
                            state = CombatState.SEARCHING;
                        }
                        continue;
                    }

                    case DONE: {
                        break;
                    }
                }
            }

            if (totalAttempts >= maxAttempts) {
                CommandExecutor.sendBridgeMessage("[Bridge] Hunt: max attempts reached (" + maxAttempts + ")");
            }
            CommandExecutor.sendBridgeMessage("[Bridge] Hunt: complete");
            ctx.taskQueue().completeActiveIf(command);
            return WorkerResult.success("combat complete");
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
}
