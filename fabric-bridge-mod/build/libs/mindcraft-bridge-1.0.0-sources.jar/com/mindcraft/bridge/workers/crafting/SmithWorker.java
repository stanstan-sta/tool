package com.mindcraft.bridge.workers.crafting;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_1703;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_4862;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmithWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");
    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = "#smith";
        try {
            if (ctx.isCancelled().get()) {
                return WorkerResult.failure("cancelled");
            }

            String template = ItemIds.normalize(CommandExecutor.extractJsonString(actionJson, "template"));
            String base = ItemIds.normalize(CommandExecutor.extractJsonString(actionJson, "base"));
            String addition = ItemIds.normalize(CommandExecutor.extractJsonString(actionJson, "addition"));
            String output = ItemIds.normalize(CommandExecutor.extractJsonString(actionJson, "output"));

            class_2338 table = WorkstationFinder.findNearestStationOnClientThread("smithing_table");
            if (table == null) {
                return WorkerResult.failure("smith: no smithing table nearby");
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            if (!CommandExecutor.waitUntilNear(table, 4.75, 30_000L, ctx.isCancelled())) {
                return WorkerResult.failure("smith: failed to reach table");
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            if (!WorldInteractor.openBlock(table)) {
                return WorkerResult.failure("smith: failed to open table");
            }

            if (!ScreenDriver.waitForHandler(class_4862.class, 3000)) {
                ScreenDriver.closeScreen();
                return WorkerResult.failure("smith: screen did not open");
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            boolean ok = ClientThread.call(() -> {
                class_746 p = class_310.method_1551().field_1724;
                class_636 im = class_310.method_1551().field_1761;
                if (p == null || im == null || !(p.field_7512 instanceof class_4862)) {
                    return false;
                }
                class_1703 screen = p.field_7512;

                int templateSlot = ScreenDriver.findSlot(screen, template, 4);
                if (templateSlot < 0) return false;
                ScreenDriver.pickup(templateSlot, class_4862.class);
                ScreenDriver.pickup(0, class_4862.class);
                ScreenDriver.pickup(templateSlot, class_4862.class);

                int baseSlot = ScreenDriver.findSlot(screen, base, 4);
                if (baseSlot < 0) return false;
                ScreenDriver.pickup(baseSlot, class_4862.class);
                ScreenDriver.pickup(1, class_4862.class);
                ScreenDriver.pickup(baseSlot, class_4862.class);

                int additionSlot = ScreenDriver.findSlot(screen, addition, 4);
                if (additionSlot < 0) return false;
                ScreenDriver.pickup(additionSlot, class_4862.class);
                ScreenDriver.pickup(2, class_4862.class);
                ScreenDriver.pickup(additionSlot, class_4862.class);

                CommandExecutor.sleep(100);

                return ScreenDriver.quickMove(3, class_4862.class);
            });

            ScreenDriver.closeScreen();

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (ok) {
                ctx.taskQueue().completeActiveIf(command);
                return WorkerResult.success("smithed");
            } else {
                return WorkerResult.failure("smith: recipe failed");
            }
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
}
