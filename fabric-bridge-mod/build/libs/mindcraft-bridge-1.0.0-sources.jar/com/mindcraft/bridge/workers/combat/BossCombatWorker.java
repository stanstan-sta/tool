package com.mindcraft.bridge.workers.combat;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1510;
import net.minecraft.class_1528;
import net.minecraft.class_1569;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BossCombatWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");

    private enum BossState {
        SCANNING,
        APPROACHING,
        ENGAGING,
        RETREATING,
        HEALING,
        DONE
    }

    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = ctx.actionType() != null ? "#" + ctx.actionType() : "#boss_combat";
        try {
            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("boss_combat: not connected");
            }

            String bossType = CommandExecutor.extractJsonString(actionJson, "boss_type");
            if (bossType == null && ctx.actionType() != null) {
                bossType = switch (ctx.actionType()) {
                    case "fight_dragon" -> "dragon";
                    case "fight_wither" -> "wither";
                    case "raid" -> "raid";
                    default -> null;
                };
            }
            if (bossType == null) {
                return WorkerResult.failure("boss_combat: missing boss_type");
            }

            WorkerResult result = switch (bossType) {
                case "dragon" -> executeDragonFight(actionJson, ctx);
                case "wither" -> executeWitherFight(actionJson, ctx);
                case "raid" -> executeRaidManagement(actionJson, ctx);
                default -> WorkerResult.failure("boss_combat: unknown boss_type " + bossType);
            };
            if (result.ok()) {
                ctx.taskQueue().completeActiveIf(command);
            }
            return result;
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }

    // ─── Dragon Fight ─────────────────────────────────────────────────────────

    private WorkerResult executeDragonFight(String actionJson, WorkerContext ctx) {
        boolean inEnd = ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            return c.field_1687 != null && c.field_1687.method_27983() == net.minecraft.class_1937.field_25181;
        });
        if (!inEnd) {
            return WorkerResult.failure("boss_combat: not in End dimension");
        }

        class_1297 dragon = findDragon();
        if (dragon == null) {
            return WorkerResult.failure("boss_combat: no dragon found");
        }

        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: dragon fight started");
        ClientThread.run(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
        });

        BossState state = BossState.SCANNING;
        int attempts = 0;
        int maxAttempts = 200;

        while (state != BossState.DONE && attempts < maxAttempts) {
            if (ctx.isCancelled().get()) {
                return WorkerResult.failure("boss_combat: cancelled");
            }

            boolean dead = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null || c.field_1724.method_29504() || c.field_1724.method_6032() <= 0;
            });
            if (dead) {
                return WorkerResult.failure("boss_combat: player died");
            }

            float hp = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null ? 999f : c.field_1724.method_6032();
            });
            if (hp <= 8.0f) {
                state = BossState.HEALING;
            }

            state = processDragonState(state, dragon);
            attempts++;
        }

        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: dragon fight complete");
        return WorkerResult.success("boss_combat: dragon fight completed");
    }

    private BossState processDragonState(BossState state, class_1297 dragon) {
        return switch (state) {
            case SCANNING -> {
                boolean alive = ClientThread.call(() -> dragon != null && dragon.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                double dist = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return Double.MAX_VALUE;
                    return c.field_1724.method_5858(dragon);
                });
                if (dist > 100.0) {
                    yield BossState.APPROACHING;
                }
                yield BossState.ENGAGING;
            }
            case APPROACHING -> {
                boolean alive = ClientThread.call(() -> dragon != null && dragon.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                class_2338 target = ClientThread.call(() -> dragon.method_24515());
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue(
                    "#goto " + target.method_10263() + " " + target.method_10264() + " " + target.method_10260()
                );
                CommandExecutor.sleepQuietly(2000);
                yield BossState.SCANNING;
            }
            case ENGAGING -> {
                boolean alive = ClientThread.call(() -> dragon != null && dragon.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                ClientThread.run(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
                });
                final class_1297 d = dragon;
                ClientThread.run(() -> {
                    class_310 client = class_310.method_1551();
                    if (client.field_1761 != null && client.field_1724 != null) {
                        client.field_1761.method_2918(client.field_1724, d);
                        client.field_1724.method_6104(class_1268.field_5808);
                    }
                });
                int cooldown = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    return c.field_1724 == null ? 500 : InventoryDriver.getAttackCooldownMs(c.field_1724);
                });
                CommandExecutor.sleepQuietly(cooldown);
                yield BossState.SCANNING;
            }
            case RETREATING -> {
                int[] retreatPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 20),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 20)
                    };
                });
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + retreatPos[0] + " " + retreatPos[1] + " " + retreatPos[2]);
                CommandExecutor.sleepQuietly(3000);
                yield BossState.SCANNING;
            }
            case HEALING -> {
                int[] healPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 30),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 30)
                    };
                });
                CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: healing...");
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + healPos[0] + " " + healPos[1] + " " + healPos[2]);
                CommandExecutor.sleepQuietly(5000);
                yield BossState.SCANNING;
            }
            default -> state;
        };
    }

    // ─── Wither Fight ─────────────────────────────────────────────────────────

    private WorkerResult executeWitherFight(String actionJson, WorkerContext ctx) {
        class_1297 wither = findWither();
        if (wither == null) {
            return WorkerResult.failure("boss_combat: no wither found");
        }

        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: wither fight started");
        ClientThread.run(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
        });

        BossState state = BossState.SCANNING;
        int attempts = 0;
        int maxAttempts = 200;

        while (state != BossState.DONE && attempts < maxAttempts) {
            if (ctx.isCancelled().get()) {
                return WorkerResult.failure("boss_combat: cancelled");
            }

            boolean dead = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null || c.field_1724.method_29504() || c.field_1724.method_6032() <= 0;
            });
            if (dead) {
                return WorkerResult.failure("boss_combat: player died");
            }

            float hp = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null ? 999f : c.field_1724.method_6032();
            });
            if (hp <= 10.0f) {
                state = BossState.HEALING;
            }

            state = processWitherState(state, wither);
            attempts++;
        }

        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: wither fight complete");
        return WorkerResult.success("boss_combat: wither fight completed");
    }

    private BossState processWitherState(BossState state, class_1297 wither) {
        return switch (state) {
            case SCANNING -> {
                boolean alive = ClientThread.call(() -> wither != null && wither.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                double dist = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return Double.MAX_VALUE;
                    return c.field_1724.method_5858(wither);
                });
                if (dist > 64.0) {
                    yield BossState.APPROACHING;
                }
                yield BossState.ENGAGING;
            }
            case APPROACHING -> {
                boolean alive = ClientThread.call(() -> wither != null && wither.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                class_2338 target = ClientThread.call(() -> wither.method_24515());
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue(
                    "#goto " + target.method_10263() + " " + target.method_10264() + " " + target.method_10260()
                );
                CommandExecutor.sleepQuietly(2000);
                yield BossState.SCANNING;
            }
            case ENGAGING -> {
                boolean alive = ClientThread.call(() -> wither != null && wither.method_5805());
                if (!alive) {
                    yield BossState.DONE;
                }
                ClientThread.run(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
                });
                final class_1297 w = wither;
                ClientThread.run(() -> {
                    class_310 client = class_310.method_1551();
                    if (client.field_1761 != null && client.field_1724 != null) {
                        client.field_1761.method_2918(client.field_1724, w);
                        client.field_1724.method_6104(class_1268.field_5808);
                    }
                });
                int cooldown = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    return c.field_1724 == null ? 500 : InventoryDriver.getAttackCooldownMs(c.field_1724);
                });
                CommandExecutor.sleepQuietly(cooldown);
                yield BossState.SCANNING;
            }
            case RETREATING -> {
                int[] retreatPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 20),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 20)
                    };
                });
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + retreatPos[0] + " " + retreatPos[1] + " " + retreatPos[2]);
                CommandExecutor.sleepQuietly(3000);
                yield BossState.SCANNING;
            }
            case HEALING -> {
                int[] healPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 30),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 30)
                    };
                });
                CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: healing...");
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + healPos[0] + " " + healPos[1] + " " + healPos[2]);
                CommandExecutor.sleepQuietly(5000);
                yield BossState.SCANNING;
            }
            default -> state;
        };
    }

    // ─── Raid Management ──────────────────────────────────────────────────────

    private WorkerResult executeRaidManagement(String actionJson, WorkerContext ctx) {
        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: raid management started");

        class_1297 nearest = findNearestRaidMob();
        if (nearest == null) {
            return WorkerResult.failure("boss_combat: no raid mobs found");
        }

        ClientThread.run(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
        });

        BossState state = BossState.SCANNING;
        int attempts = 0;
        int maxAttempts = 100;

        while (state != BossState.DONE && attempts < maxAttempts) {
            if (ctx.isCancelled().get()) {
                return WorkerResult.failure("boss_combat: cancelled");
            }

            boolean dead = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null || c.field_1724.method_29504() || c.field_1724.method_6032() <= 0;
            });
            if (dead) {
                return WorkerResult.failure("boss_combat: player died");
            }

            float hp = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 == null ? 999f : c.field_1724.method_6032();
            });
            if (hp <= 10.0f) {
                state = BossState.HEALING;
            }

            state = processRaidState(state);
            attempts++;
        }

        CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: raid complete");
        return WorkerResult.success("boss_combat: raid completed");
    }

    private BossState processRaidState(BossState state) {
        return switch (state) {
            case SCANNING -> {
                class_1297 target = findNearestRaidMob();
                if (target == null) {
                    yield BossState.DONE;
                }
                double dist = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return Double.MAX_VALUE;
                    return c.field_1724.method_5858(target);
                });
                if (dist > 16.0) {
                    yield BossState.APPROACHING;
                }
                yield BossState.ENGAGING;
            }
            case APPROACHING -> {
                class_1297 target = findNearestRaidMob();
                if (target == null) {
                    yield BossState.DONE;
                }
                class_2338 pos = ClientThread.call(() -> target.method_24515());
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue(
                    "#goto " + pos.method_10263() + " " + pos.method_10264() + " " + pos.method_10260()
                );
                CommandExecutor.sleepQuietly(2000);
                yield BossState.SCANNING;
            }
            case ENGAGING -> {
                class_1297 target = findNearestRaidMob();
                if (target == null) {
                    yield BossState.DONE;
                }
                ClientThread.run(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 != null) InventoryDriver.equipBestWeapon(c.field_1724);
                });
                final class_1297 m = target;
                ClientThread.run(() -> {
                    class_310 client = class_310.method_1551();
                    if (client.field_1761 != null && client.field_1724 != null) {
                        client.field_1761.method_2918(client.field_1724, m);
                        client.field_1724.method_6104(class_1268.field_5808);
                    }
                });
                int cooldown = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    return c.field_1724 == null ? 500 : InventoryDriver.getAttackCooldownMs(c.field_1724);
                });
                CommandExecutor.sleepQuietly(cooldown);
                yield BossState.SCANNING;
            }
            case RETREATING -> {
                int[] retreatPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 15),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 15)
                    };
                });
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + retreatPos[0] + " " + retreatPos[1] + " " + retreatPos[2]);
                CommandExecutor.sleepQuietly(3000);
                yield BossState.SCANNING;
            }
            case HEALING -> {
                int[] healPos = ClientThread.call(() -> {
                    class_310 c = class_310.method_1551();
                    if (c.field_1724 == null) return new int[]{0, 64, 0};
                    return new int[]{
                        (int) Math.floor(c.field_1724.method_23317() - 25),
                        (int) Math.floor(c.field_1724.method_23318()),
                        (int) Math.floor(c.field_1724.method_23321() - 25)
                    };
                });
                CommandExecutor.sendBridgeMessage("[Bridge] BossCombat: healing...");
                TaskQueue.getInstance().cancelAll();
                CommandExecutor.sleepQuietly(100);
                TaskQueue.getInstance().enqueue("#goto " + healPos[0] + " " + healPos[1] + " " + healPos[2]);
                CommandExecutor.sleepQuietly(5000);
                yield BossState.SCANNING;
            }
            default -> state;
        };
    }

    // ─── Entity Finders ───────────────────────────────────────────────────────

    private class_1297 findDragon() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(256),
                e -> e instanceof class_1510 && e.method_5805()
            ).stream().findFirst().orElse(null);
        });
    }

    private class_1297 findWither() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(128),
                e -> e instanceof class_1528 && e.method_5805()
            ).stream().findFirst().orElse(null);
        });
    }

    private class_1297 findNearestRaidMob() {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1687 == null || c.field_1724 == null) return null;
            return c.field_1687.method_8333(null,
                c.field_1724.method_5829().method_1014(64),
                e -> e instanceof class_1569 && e.method_5805()
            ).stream().findFirst().orElse(null);
        });
    }

    @Override
    public boolean requiresThread() {
        return true;
    }
}
