package com.mindcraft.bridge.workers.crafting;

import com.mindcraft.bridge.*;
import com.mindcraft.bridge.workers.*;
import net.minecraft.class_1703;
import net.minecraft.class_1718;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnchantWorker implements Worker {
    private static final Logger LOGGER = LoggerFactory.getLogger("mindcraft-bridge");
    @Override
    public WorkerResult execute(String actionJson, WorkerContext ctx) {
        String command = "#enchant";
        try {
            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");

            String item = CommandExecutor.extractJsonString(actionJson, "item");
            String level = CommandExecutor.extractJsonString(actionJson, "level");
            String lapis = CommandExecutor.extractJsonString(actionJson, "lapis");

            boolean connected = ClientThread.call(() -> {
                class_310 c = class_310.method_1551();
                return c.field_1724 != null && c.field_1687 != null;
            });
            if (!connected) {
                return WorkerResult.failure("enchant: not connected");
            }

            class_2338 table = WorkstationFinder.findNearestStationOnClientThread("enchanting_table");
            if (table == null) {
                return WorkerResult.failure("enchant: no enchanting table nearby");
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (!CommandExecutor.waitUntilNear(table, 4.75, 30_000L, ctx.isCancelled())) {
                return WorkerResult.failure("enchant: failed to reach table");
            }

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (!WorldInteractor.openBlock(table)) {
                return WorkerResult.failure("enchant: failed to open table");
            }

            if (!ScreenDriver.waitForHandler(class_1718.class, 3000)) {
                ScreenDriver.closeScreen();
                return WorkerResult.failure("enchant: screen did not open");
            }

            boolean ok = ClientThread.call(() -> {
                class_746 p = class_310.method_1551().field_1724;
                class_636 im = class_310.method_1551().field_1761;
                if (p == null || im == null || !(p.field_7512 instanceof class_1718 handler)) return false;
                class_1703 screen = p.field_7512;

                if (item != null) {
                    String normItem = ItemIds.normalize(item);
                    int itemSlot = ScreenDriver.findSlot(screen, normItem, 2);
                    if (itemSlot >= 0) {
                        ScreenDriver.pickup(itemSlot, class_1718.class);
                        ScreenDriver.pickup(0, class_1718.class);
                        ScreenDriver.pickup(itemSlot, class_1718.class);
                    }
                }
                CommandExecutor.sleep(100); // Wait for server acknowledgment

                if (lapis != null) {
                    String normLapis = ItemIds.normalize(lapis);
                    int lapisSlot = ScreenDriver.findSlot(screen, normLapis, 2);
                    if (lapisSlot >= 0) {
                        ScreenDriver.pickup(lapisSlot, class_1718.class);
                        ScreenDriver.pickup(1, class_1718.class);
                        ScreenDriver.pickup(lapisSlot, class_1718.class);
                    }
                }
                CommandExecutor.sleep(100); // Wait for server acknowledgment

                if (level != null) {
                    try {
                        int buttonIndex = Integer.parseInt(level);
                        if (buttonIndex >= 0 && buttonIndex < 3) {
                            if (p.field_3944 != null) {
                                p.field_3944.method_52787(
                                    new net.minecraft.class_2811(
                                        handler.field_7763, buttonIndex));
                            }
                        }
                    } catch (NumberFormatException ignored) {}
                }

                CommandExecutor.sleep(200); // Longer wait for final operation
                return ScreenDriver.quickMove(0, class_1718.class);
            });

            ScreenDriver.closeScreen();

            if (ctx.isCancelled().get()) return WorkerResult.failure("cancelled");
            if (ok) {
                ctx.taskQueue().completeActiveIf(command);
                return WorkerResult.success("enchanted");
            } else {
                return WorkerResult.failure("enchant: " + command + " failed");
            }
        } catch (Exception e) {
            LOGGER.error(command + " worker crashed", e);
            ctx.taskQueue().failActiveIf(command, command + ": " + e.getMessage());
            return WorkerResult.failure(command + ": " + e.getMessage());
        } finally {
            try { ScreenDriver.closeScreen(); } catch (Exception ignored) {}
        }
    }
}
