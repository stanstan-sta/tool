package com.mindcraft.bridge;

import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Collects the current player state into a JSON string.
 *
 * State includes: position, health, hunger, saturation, dimension, game mode,
 * inventory, and nearby players. Chat messages received since the last /state
 * call are appended and then cleared (so callers see only new messages).
 */
public class StateCollector {

    /** Thread-safe queue of chat messages received since the last /state poll. */
    static final Queue<String> chatQueue = new ConcurrentLinkedQueue<>();
    static final int MAX_CHAT_QUEUE = 200;
    private static String lastStateHash = "";
    private static final AtomicLong stateSeq = new AtomicLong(0);

    /**
     * Register the Fabric chat-receive event listener.
     * Called once from {@link MindcraftBridgeMod#onInitializeClient()}.
     */
    public static void registerEvents() {
        // Listen for incoming chat messages and queue them for the Node.js agent.
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) {
                while (chatQueue.size() >= MAX_CHAT_QUEUE) {
                    chatQueue.poll();
                }
                chatQueue.add(message.getString());
            }
        });
    }

    /** Build and return the complete state as a JSON string. */
    public static String collect(Long sinceSeq) {
        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;

        if (player == null || client.field_1687 == null) {
            return "{\"connected\":false}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("{");

        sb.append("\"connected\":true,");

        // Position
        int x = (int) Math.floor(player.method_23317());
        int y = (int) Math.floor(player.method_23318());
        int z = (int) Math.floor(player.method_23321());
        sb.append(String.format("\"x\":%d,\"y\":%d,\"z\":%d,", x, y, z));

        // Vitals
        sb.append(String.format("\"health\":%.1f,", player.method_6032()));
        sb.append(String.format("\"hunger\":%d,", player.method_7344().method_7586()));
        sb.append(String.format("\"saturation\":%.1f,", player.method_7344().method_7589()));

        // World info
        String dim = client.field_1687.method_27983().method_29177().toString();
        sb.append(String.format("\"dimension\":\"%s\",", dim));

        // Game mode — GameMode.getName() was removed in 1.21.11;
        // use the standard Java enum name() and lower-case it instead.
        String mode = (client.field_1761 != null && client.field_1761.method_2920() != null)
                ? client.field_1761.method_2920().name().toLowerCase()
                : "unknown";
        sb.append(String.format("\"gameMode\":\"%s\",", mode));

        // Inventory
        StringBuilder invSig = new StringBuilder();
        sb.append("\"inventory\":[");
        class_1661 inv = player.method_31548();
        boolean firstItem = true;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            if (!firstItem) sb.append(",");
            firstItem = false;
            String itemId = stack.method_7909().toString(); // "minecraft:oak_log"
            invSig.append(i).append(':').append(itemId).append(':').append(stack.method_7947()).append(';');
            sb.append(String.format("{\"slot\":%d,\"item\":\"%s\",\"count\":%d}",
                    i, escape(itemId), stack.method_7947()));
        }
        sb.append("],");

        // Nearby players (within 64 blocks)
        StringBuilder playersSig = new StringBuilder();
        sb.append("\"nearby_players\":[");
        class_238 searchBox = player.method_5829().method_1014(64);
        List<class_1297> entities = client.field_1687.method_8333(player, searchBox,
                e -> e instanceof net.minecraft.class_1657);
        boolean firstPlayer = true;
        for (class_1297 e : entities) {
            if (!firstPlayer) sb.append(",");
            firstPlayer = false;
            playersSig.append(e.method_5477().getString()).append(';');
            sb.append("\"").append(escape(e.method_5477().getString())).append("\"");
        }
        sb.append("],");

        // Nearby non-player entities with precise coordinates and velocity
        StringBuilder entitiesSig = new StringBuilder();
        sb.append("\"nearby_entities\":[");
        List<class_1297> nearbyEntities = client.field_1687.method_8333(player, searchBox,
                e -> !(e instanceof net.minecraft.class_1657));
        boolean firstEntity = true;
        for (class_1297 e : nearbyEntities) {
            if (!firstEntity) sb.append(",");
            firstEntity = false;
            class_243 v = e.method_18798();
            double ex = e.method_23317();
            double ey = e.method_23318();
            double ez = e.method_23321();
            entitiesSig.append(e.method_5864().toString()).append('@')
                    .append(round(ex)).append(',').append(round(ey)).append(',').append(round(ez)).append(';');
            sb.append("{")
                    .append("\"name\":\"").append(escape(e.method_5477().getString())).append("\",")
                    .append("\"type\":\"").append(escape(e.method_5864().toString())).append("\",")
                    .append("\"x\":").append(round(ex)).append(",")
                    .append("\"y\":").append(round(ey)).append(",")
                    .append("\"z\":").append(round(ez)).append(",")
                    .append("\"vx\":").append(round(v.field_1352)).append(",")
                    .append("\"vy\":").append(round(v.field_1351)).append(",")
                    .append("\"vz\":").append(round(v.field_1350))
                    .append("}");
        }
        sb.append("],");

        String stateHash = x + "|" + y + "|" + z + "|" + player.method_6032() + "|" +
                player.method_7344().method_7586() + "|" + dim + "|" + mode + "|" +
                invSig + "|" + playersSig + "|" + entitiesSig;
        if (!stateHash.equals(lastStateHash)) {
            lastStateHash = stateHash;
            stateSeq.incrementAndGet();
        }
        long seq = stateSeq.get();

        if (sinceSeq != null && sinceSeq == seq && chatQueue.isEmpty()) {
            return "{\"connected\":true,\"seq\":" + seq + ",\"unchanged\":true,\"chat\":[]}";
        }

        // Chat messages received since last poll — drain the queue
        sb.append("\"chat\":[");
        boolean firstChat = true;
        String msg;
        while ((msg = chatQueue.poll()) != null) {
            if (!firstChat) sb.append(",");
            firstChat = false;
            sb.append("\"").append(escape(msg)).append("\"");
        }
        sb.append("]");
        sb.append(",\"seq\":").append(seq);
        sb.append(",\"unchanged\":false");

        sb.append("}");
        return sb.toString();
    }

    /** Minimal JSON string escape. */
    private static String escape(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static String round(double v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }
}