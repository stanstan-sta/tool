package com.mindcraft.bridge;

import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Collects the current player state into a JSON string.
 *
 * State includes: position, health, hunger, saturation, dimension, game mode,
 * inventory, nearby players, and structured chat events. Chat messages received
 * since the last /state call are appended and then cleared (so callers see only
 * new messages).
 */
public class StateCollector {

            static final Queue<ChatEvent> chatQueue = new ConcurrentLinkedQueue<>();
    static final int MAX_CHAT_QUEUE = 200;
    private static final Queue<WorldEvent> worldEventQueue = new ConcurrentLinkedQueue<>();
    private static final int MAX_WORLD_EVENTS = 32;
    private static String lastStateHash = "";
    private static final AtomicLong stateSeq = new AtomicLong(0);

    // Track recently-sent chat messages so they can be excluded from the
    // GAME listener, which otherwise echoes them back and causes a loop.
    private static final Queue<String> recentSentChats = new ConcurrentLinkedQueue<>();
    private static final int MAX_SENT_TRACK = 16;

    // Idle / transition tracking
    private static long lastPlayerChatMs = System.currentTimeMillis();
    private static String lastDayPhase = "day";
    private static boolean lastWasRaining = false;
    private static boolean lastWasThundering = false;
    private static int lastHostileCount = 0;
    private static long lastHostileEventMs = 0;
    private static String lastDimension = "minecraft:overworld";

    static final int LOW_HP_THRESHOLD = 8;
    static final int LOW_FOOD_THRESHOLD = 6;
    private static final java.util.Set<String> NEARBY_BLOCK_SUMMARY_IDS = java.util.Set.of(
            "minecraft:chest", "minecraft:trapped_chest", "minecraft:barrel", "minecraft:shulker_box",
            "minecraft:white_shulker_box", "minecraft:orange_shulker_box", "minecraft:magenta_shulker_box",
            "minecraft:light_blue_shulker_box", "minecraft:yellow_shulker_box", "minecraft:lime_shulker_box",
            "minecraft:pink_shulker_box", "minecraft:gray_shulker_box", "minecraft:light_gray_shulker_box",
            "minecraft:cyan_shulker_box", "minecraft:purple_shulker_box", "minecraft:blue_shulker_box",
            "minecraft:brown_shulker_box", "minecraft:green_shulker_box", "minecraft:red_shulker_box",
            "minecraft:black_shulker_box", "minecraft:furnace", "minecraft:blast_furnace", "minecraft:smoker",
            "minecraft:brewing_stand", "minecraft:smithing_table", "minecraft:enchanting_table",
            "minecraft:lectern", "minecraft:nether_portal", "minecraft:repeater", "minecraft:comparator",
            "minecraft:redstone_wire", "minecraft:lever", "minecraft:stone_button", "minecraft:oak_button",
            "minecraft:stone_pressure_plate", "minecraft:oak_pressure_plate", "minecraft:hopper", "minecraft:dropper",
            "minecraft:dispenser", "minecraft:observer", "minecraft:piston", "minecraft:sticky_piston");

    public static void pushWorldEvent(String type, String detail) {
        while (worldEventQueue.size() >= MAX_WORLD_EVENTS) {
            worldEventQueue.poll();
        }
        worldEventQueue.add(new WorldEvent(type, detail));
    }

    public static void trackSentChat(String message) {
        while (recentSentChats.size() >= MAX_SENT_TRACK) {
            recentSentChats.poll();
        }
        recentSentChats.add(message);
    }

    private static void routeBaritoneToTaskQueue(String content) {
        String clean = stripChatFormatting(content);
        if (clean == null || !clean.contains("[Baritone]")) return;
        if (clean.contains("All queued tasks complete")) {
            TaskQueue.getInstance().onBaritoneComplete();
        } else if (clean.contains("Task failed:")) {
            String reason = clean.substring(clean.indexOf("Task failed:") + "Task failed:".length()).trim();
            TaskQueue.getInstance().onBaritoneFailed(reason);
        } else if (isBaritoneFailureMessage(clean)) {
            TaskQueue.getInstance().onBaritoneFailed(clean);
        }
    }

    private static boolean isBaritoneFailureMessage(String clean) {
        String lower = clean.toLowerCase(java.util.Locale.ROOT);
        return lower.contains("unable to find any path")
                || lower.contains("cancelling mine")
                || lower.contains("canceling mine")
                || lower.contains("no path")
                || lower.contains("path calculation failed");
    }

    /**
     * Register the Fabric chat-receive event listener.
     * Called once from {@link MindcraftBridgeMod#onInitializeClient()}.
     */
    public static void registerEvents() {
        // Listen for incoming chat messages and queue them for the Node.js agent.
        // CHAT covers normal player chat, GAME covers overlay/system messages.
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            while (chatQueue.size() >= MAX_CHAT_QUEUE) {
                chatQueue.poll();
            }
            String content = message.getString();

            // Route Baritone status messages even when they come through the CHAT channel
            // (some Baritone builds emit them as player chat rather than system overlay).
            String cleanContent = stripChatFormatting(content);
            if (cleanContent != null && cleanContent.contains("[Baritone]")) {
                routeBaritoneToTaskQueue(cleanContent);
                chatQueue.add(new ChatEvent("baritone_queue", cleanContent, null));
                return;
            }

            String senderName = null;
            if (sender != null) {
                try {
                    java.lang.reflect.Method method = sender.getClass().getMethod("getName");
                    Object nameObj = method.invoke(sender);
                    if (nameObj != null) {
                        senderName = nameObj.toString();
                    }
                } catch (Throwable ignored) {
                    senderName = sender.toString();
                }
            }
            class_310 client = class_310.method_1551();
            class_746 player = client != null ? client.field_1724 : null;
            if (senderName != null && player != null) {
                String selfName = player.method_5477().getString();
                if (senderName.equals(selfName)) {
                    return;
                }
            }
            lastPlayerChatMs = System.currentTimeMillis();
            chatQueue.add(new ChatEvent("player", message.getString(), senderName));
        });

                        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            while (chatQueue.size() >= MAX_CHAT_QUEUE) {
                chatQueue.poll();
            }
            String content = message.getString();
            // Skip messages that match a recently sent chat to prevent the
            // echo loop: Node sends "chat:..." → mod sends via network →
            // GAME listener fires with the same text → Node picks it up →
            // LLM responds → repeat.
            if (content != null && recentSentChats.contains(content)) {
                return;
            }
            // Detect Baritone task-queue status messages and route to TaskQueue.
            // The contract: Baritone logs "[Baritone] All queued tasks complete"
            // on success and "[Baritone] Task failed: <label> - <outcome>" on failure.
            String cleanContent = stripChatFormatting(content);
            if (cleanContent != null && cleanContent.contains("[Baritone]")) {
                routeBaritoneToTaskQueue(cleanContent);
                chatQueue.add(new ChatEvent("baritone_queue", cleanContent, null));
                return;
            }
            String type = overlay ? "system" : "player";
            chatQueue.add(new ChatEvent(type, content, null));
        });
    }

    /** Build and return the complete state as a JSON string. */
    public static String collect(Long sinceSeq, boolean includeSurfaceMap, int surfaceRadius) {
        class_310 client = class_310.method_1551();
        if (client.method_18854()) {
            return collectOnClientThread(sinceSeq, includeSurfaceMap, surfaceRadius);
        }
        try {
            return ClientThread.call(() -> collectOnClientThread(sinceSeq, includeSurfaceMap, surfaceRadius));
        } catch (Exception e) {
            return "{\"connected\":false,\"error\":\"STATE_COLLECT_FAILED\"}";
        }
    }

    private static String collectOnClientThread(Long sinceSeq, boolean includeSurfaceMap, int surfaceRadius) {
        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;

        if (player == null || client.field_1687 == null) {
            return "{\"connected\":false}";
        }

        // Get XP and handler info early
        int xpLevel = player.field_7520;
        float xpProgress = player.field_7510;
        String handlerClassName = player.field_7512 != null ? player.field_7512.getClass().getName() : "";

        StringBuilder sb = new StringBuilder();
        sb.append("{");

        try {
        sb.append("\"connected\":true,");
        sb.append("\"player_name\":\"").append(escape(player.method_5477().getString())).append("\",");

        // Position
        int x = (int) Math.floor(player.method_23317());
        int y = (int) Math.floor(player.method_23318());
        int z = (int) Math.floor(player.method_23321());
        sb.append(String.format("\"x\":%d,\"y\":%d,\"z\":%d,", x, y, z));

        // Vitals
        float health = player.method_6032();
        int hunger = player.method_7344().method_7586();
        sb.append(String.format("\"health\":%.1f,", health));
        sb.append(String.format("\"hunger\":%d,", hunger));
        sb.append(String.format("\"saturation\":%.1f,", player.method_7344().method_7589()));

        // Time & weather
        long timeOfDay = 0;
        long dayNumber = 0;
        String dayPhase = "unknown";
        boolean raining = false;
        boolean thundering = false;
        if (client.field_1687 != null) {
            timeOfDay = client.field_1687.method_8532() % 24000L;
            dayNumber = client.field_1687.method_8532() / 24000L;
            // day: 0..12000, dusk: 12000..13000, night: 13000..23000, dawn: 23000..24000
            dayPhase = timeOfDay < 12000 ? "day"
                    : timeOfDay < 13000 ? "dusk"
                    : timeOfDay < 23000 ? "night" : "dawn";
            raining = client.field_1687.method_8419();
            thundering = client.field_1687.method_8546();
        }
        sb.append(String.format("\"time_of_day_ticks\":%d,", timeOfDay));
        sb.append(String.format("\"day_number\":%d,", dayNumber));
        sb.append(String.format("\"day_phase\":\"%s\",", dayPhase));
        sb.append(String.format("\"is_raining\":%b,", raining));
        sb.append(String.format("\"is_thundering\":%b,", thundering));

        // World info
        String dim = "unknown";
        if (client.field_1687 != null) {
            dim = client.field_1687.method_27983().method_29177().toString();
        }
        sb.append(String.format("\"dimension\":\"%s\",", dim));

        // Game mode — GameMode.getName() was removed in 1.21.11;
        // use the standard Java enum name() and lower-case it instead.
        String mode = (client.field_1761 != null && client.field_1761.method_2920() != null)
                ? client.field_1761.method_2920().name().toLowerCase()
                : "unknown";
        sb.append(String.format("\"gameMode\":\"%s\",", mode));

        // Inventory
        StringBuilder invSig = new StringBuilder();
        sb.append("\"inventory\":[");
        class_1661 inv = player.method_31548();
        boolean firstItem = true;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            if (!firstItem) sb.append(",");
            firstItem = false;
            String itemId = getItemId(stack); // e.g. "minecraft:oak_log"
            invSig.append(i).append(':').append(itemId).append(':').append(stack.method_7947()).append(';');
            sb.append(String.format("{\"slot\":%d,\"item\":\"%s\",\"count\":%d}",
                    i, escape(itemId), stack.method_7947()));
        }
        sb.append("],");

        // Craftable items based on current inventory
        sb.append("\"craftable\":");
        appendCraftable(sb, inv);
        sb.append(",");

        // Nearby players (within 64 blocks)
        StringBuilder playersSig = new StringBuilder();
        sb.append("\"nearby_players\":[");
        class_238 searchBox = player.method_5829().method_1014(64);
        List<class_1297> entities = client.field_1687 != null
                ? client.field_1687.method_8333(player, searchBox,
                        e -> e instanceof net.minecraft.class_1657)
                : java.util.Collections.emptyList();
        boolean firstPlayer = true;
        for (class_1297 e : entities) {
            if (!firstPlayer) sb.append(",");
            firstPlayer = false;
            playersSig.append(e.method_5477().getString()).append(';');
            sb.append("\"").append(escape(e.method_5477().getString())).append("\"");
        }
        sb.append("],");

        // Nearby non-player entities with precise coordinates and velocity
        StringBuilder entitiesSig = new StringBuilder();
        sb.append("\"nearby_entities\":[");
        List<class_1297> nearbyEntities = client.field_1687 != null
                ? client.field_1687.method_8333(player, searchBox,
                        e -> !(e instanceof net.minecraft.class_1657))
                : java.util.Collections.emptyList();
        boolean firstEntity = true;
        for (class_1297 e : nearbyEntities) {
            if (!firstEntity) sb.append(",");
            firstEntity = false;
            class_243 v = e.method_18798();
            double ex = e.method_23317();
            double ey = e.method_23318();
            double ez = e.method_23321();
            entitiesSig.append(e.method_5864().toString()).append('@')
                    .append(round(ex)).append(',').append(round(ey)).append(',').append(round(ez)).append(';');
            sb.append("{")
                    .append("\"name\":\"").append(escape(e.method_5477().getString())).append("\",")
                    .append("\"type\":\"").append(escape(e.method_5864().toString())).append("\",")
                    .append("\"x\":").append(round(ex)).append(",")
                    .append("\"y\":").append(round(ey)).append(",")
                    .append("\"z\":").append(round(ez)).append(",")
                    .append("\"vx\":").append(round(v.field_1352)).append(",")
                    .append("\"vy\":").append(round(v.field_1351)).append(",")
                    .append("\"vz\":").append(round(v.field_1350))
                    .append("}");
        }
        sb.append("],");

        // Hostile mob summary
        int hostileCount = 0;
        class_1297 nearestHostile = null;
        double nearestHostileDist = Double.MAX_VALUE;
        for (class_1297 e : nearbyEntities) {
            if (isHostile(e)) {
                hostileCount++;
                double dist = player.method_5858(e);
                if (dist < nearestHostileDist) {
                    nearestHostileDist = dist;
                    nearestHostile = e;
                }
            }
        }
        sb.append(String.format("\"hostile_count_nearby\":%d,", hostileCount));
        if (nearestHostile != null) {
            double hd = Math.sqrt(nearestHostileDist);
            sb.append(String.format("\"nearest_hostile\":{\"type\":\"%s\",\"distance\":%.1f},",
                    escape(nearestHostile.method_5864().toString()), hd));
        } else {
            sb.append("\"nearest_hostile\":null,");
        }

        // Status flags & idle timers
        boolean lowHp = health <= LOW_HP_THRESHOLD;
        boolean lowFood = hunger <= LOW_FOOD_THRESHOLD;
        long now = System.currentTimeMillis();
        long botIdle = now - TaskQueue.getInstance().getLastActivityMs();
        long playerIdle = now - lastPlayerChatMs;
        sb.append(String.format("\"low_hp_flag\":%b,", lowHp));
        sb.append(String.format("\"low_food_flag\":%b,", lowFood));
        sb.append(String.format("\"bot_idle_ms\":%d,", botIdle));
        sb.append(String.format("\"player_idle_ms\":%d,", playerIdle));

        // Phase 1: selected slot + held items
        appendHeldItems(sb, player);

        // Phase 1: equipment
        appendEquipment(sb, player);
        appendEquipmentDetail(sb, player);

        // Phase 1: status effects (sorted by id, no duration in hash)
        appendEffects(sb, player);

        // Phase 1: XP
        appendXp(sb, player);

        // Phase 1: open screen
        appendOpenScreen(sb, client, player);
        appendTargetedBlock(sb, client, player);
        appendTargetedEntity(sb, client, player);
        appendEnvironment(sb, client, player);
        appendNearbyBlockEntities(sb, player, client.field_1687);

        if (includeSurfaceMap && client.field_1687 != null) {
            appendSurfaceMap(sb, player, client.field_1687, surfaceRadius);
        }

        // Emit world events for state transitions
        if (!dayPhase.equals(lastDayPhase)) {
            if ("night".equals(dayPhase)) pushWorldEvent("night_start", "");
            if ("dawn".equals(dayPhase)) pushWorldEvent("sunrise", "");
            lastDayPhase = dayPhase;
        }
        if (raining && !lastWasRaining) {
            pushWorldEvent("weather_start_rain", "");
        } else if (!raining && lastWasRaining) {
            pushWorldEvent("weather_end_rain", "");
        }
        if (thundering && !lastWasThundering) {
            pushWorldEvent("weather_start_thunder", "");
        } else if (!thundering && lastWasThundering) {
            pushWorldEvent("weather_end_thunder", "");
        }
        lastWasRaining = raining;
        lastWasThundering = thundering;

        if (hostileCount > 0 && lastHostileCount == 0) {
            pushWorldEvent("hostile_entered_range", String.valueOf(hostileCount));
            lastHostileEventMs = now;
        } else if (hostileCount > lastHostileCount && hostileCount > 0
                && (now - lastHostileEventMs) > 30_000L) {
            pushWorldEvent("hostile_entered_range", String.valueOf(hostileCount));
            lastHostileEventMs = now;
        }
        if (hostileCount == 0 && lastHostileCount > 0) {
            // quiet window reset
        }
        lastHostileCount = hostileCount;

        // Dimension transition events
        if (!dim.equals(lastDimension)) {
            if (dim.contains("nether")) pushWorldEvent("entered_nether", "");
            else if (dim.contains("end")) pushWorldEvent("entered_end", "");
            else pushWorldEvent("entered_overworld", "");
            lastDimension = dim;
        }

        // Effect hash: id+amplifier+ambient only (no duration_ticks to avoid noisy seq bumps)
        StringBuilder effectsSig = new StringBuilder();
        java.util.Collection<class_1293> statusEffects = player.method_6026();
        if (statusEffects != null) {
            java.util.List<class_1293> sortedEffects = new java.util.ArrayList<>(statusEffects);
            sortedEffects.sort((a, b) -> {
                String idA = a.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(a.method_5579().comp_349()).toString()
                        : "";
                String idB = b.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(b.method_5579().comp_349()).toString()
                        : "";
                return idA.compareTo(idB);
            });
            for (class_1293 effect : sortedEffects) {
                String eid = effect.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(effect.method_5579().comp_349()).toString()
                        : "unknown";
                effectsSig.append(eid).append(':').append(effect.method_5578()).append(':').append(effect.method_5591()).append(';');
            }
        }

        int selectedSlot = player.method_31548().method_67532();
        String mainHandId = getItemId(player.method_6047());
        int mainHandCount = player.method_6047().method_7960() ? 0 : player.method_6047().method_7947();
        String offHandId = getItemId(player.method_6079());
        int offHandCount = player.method_6079().method_7960() ? 0 : player.method_6079().method_7947();
        String headId = getItemId(player.method_6118(class_1304.field_6169));
        int headCount = player.method_6118(class_1304.field_6169).method_7960() ? 0 : player.method_6118(class_1304.field_6169).method_7947();
        String chestId = getItemId(player.method_6118(class_1304.field_6174));
        int chestCount = player.method_6118(class_1304.field_6174).method_7960() ? 0 : player.method_6118(class_1304.field_6174).method_7947();
        String legsId = getItemId(player.method_6118(class_1304.field_6172));
        int legsCount = player.method_6118(class_1304.field_6172).method_7960() ? 0 : player.method_6118(class_1304.field_6172).method_7947();
        String feetId = getItemId(player.method_6118(class_1304.field_6166));
        int feetCount = player.method_6118(class_1304.field_6166).method_7960() ? 0 : player.method_6118(class_1304.field_6166).method_7947();
        String screenClass = client.field_1755 == null ? "" : client.field_1755.getClass().getName();
        String handlerClass = player.field_7512 == null ? "" : player.field_7512.getClass().getName();
        boolean screenOpen = client.field_1755 != null;
        String targetSig = targetSignature(client, player);
        String envSig = environmentSignature(client, player);
        String openScreenSig = openScreenSignature(client, player);
        String blockEntitySig = nearbyBlockEntitiesSignature(player, client.field_1687);

        String stateHash = x + "|" + y + "|" + z + "|" + health + "|" + hunger + "|" +
                dim + "|" + mode + "|" + dayPhase + "|" + raining + "|" + thundering + "|" +
                hostileCount + "|" + lowHp + "|" + lowFood + "|" +
                invSig + "|" + playersSig + "|" + entitiesSig + "|" +
                selectedSlot + "|" + mainHandId + ":" + mainHandCount + "|" + offHandId + ":" + offHandCount + "|" +
                headId + ":" + headCount + "|" + chestId + ":" + chestCount + "|" +
                legsId + ":" + legsCount + "|" + feetId + ":" + feetCount + "|" +
                effectsSig + "|" +
                screenOpen + "|" + screenClass + "|" + handlerClass + "|" + openScreenSig + "|" +
                targetSig + "|" + envSig + "|" + blockEntitySig;
        TaskQueue.QueueState qs = TaskQueue.getInstance().getQueueState();
        stateHash += "|" + qs.status() + "|" + (qs.activeActionType() != null ? qs.activeActionType() : "") + "|" +
                qs.pending() + "|" + qs.paused() + "|" + (qs.lastFailure() != null ? qs.lastFailure() : "") + "|" +
                (player.field_7512 != null ? player.field_7512.getClass().getName() : "") + "|" +
                player.field_7520 + "|" + player.field_7510;
        if (!stateHash.equals(lastStateHash)) {
            lastStateHash = stateHash;
            stateSeq.incrementAndGet();
        }
        long seq = stateSeq.get();

        if (sinceSeq != null && sinceSeq == seq && chatQueue.isEmpty() && worldEventQueue.isEmpty()) {
            return "{\"connected\":true,\"seq\":" + seq + ",\"player_name\":\"" + escape(player.method_5477().getString()) + "\",\"unchanged\":true,\"chat\":[],\"chat_events\":[],\"recent_events\":[]}";
        }

        // Chat messages received since last poll — drain the queue into both legacy and structured arrays.
        StringBuilder chatArray = new StringBuilder();
        StringBuilder eventArray = new StringBuilder();
        chatArray.append("[");
        eventArray.append("[");
        boolean firstChat = true;
        boolean firstEvent = true;
        ChatEvent event;
        while ((event = chatQueue.poll()) != null) {
            if (!firstChat) chatArray.append(",");
            firstChat = false;
            chatArray.append("\"").append(escape(event.message)).append("\"");

            if (!firstEvent) eventArray.append(",");
            firstEvent = false;
            eventArray.append(event.toJson());
        }
        chatArray.append("]");
        eventArray.append("]");

        sb.append("\"chat\":").append(chatArray).append(",");
        sb.append("\"chat_events\":").append(eventArray).append(",");

        // World events emitted since last poll
        StringBuilder worldEventArray = new StringBuilder();
        worldEventArray.append("[");
        boolean firstWorldEvent = true;
        WorldEvent we;
        while ((we = worldEventQueue.poll()) != null) {
            if (!firstWorldEvent) worldEventArray.append(",");
            firstWorldEvent = false;
            worldEventArray.append(we.toJson());
        }
        worldEventArray.append("]");
        sb.append("\"recent_events\":").append(worldEventArray);

        sb.append(",\"seq\":").append(seq);
        sb.append(",\"unchanged\":false");

        // Append task queue state
        TaskQueue.QueueState qs2 = TaskQueue.getInstance().getQueueState();
        if (!"idle".equals(qs2.status()) && !"disabled".equals(qs2.status())) {
            sb.append(",\"queue\":{");
            sb.append("\"status\":\"").append(escape(qs2.status())).append("\",");
            sb.append("\"active\":").append(qs2.active() == null ? "null" : "\"" + escape(qs2.active()) + "\"").append(",");
            if (qs2.kind() != null) {
                sb.append("\"kind\":\"").append(escape(qs2.kind())).append("\",");
            }
            if (qs2.completion() != null) {
                sb.append("\"completion\":\"").append(escape(qs2.completion())).append("\",");
            }
            sb.append("\"pending\":").append(qs2.pending()).append(",");
            sb.append("\"paused\":").append(qs2.paused());
            if (qs2.lastFailure() != null) {
                sb.append(",\"lastFailure\":\"").append(escape(qs2.lastFailure())).append("\"");
            }
            sb.append("}");
        }

        // Append builder state. Present only when Baritone's BuilderProcess
        // is active, so the Node side can watch it go idle to detect completion.
        Boolean builderActive = CommandExecutor.isBuilderActive();
        if (Boolean.TRUE.equals(builderActive)) {
            sb.append(",\"builder\":{\"active\":true}");
        }

        sb.append("}");
        return sb.toString();
        } catch (Exception e) {
            return "{\"connected\":true,\"seq\":" + stateSeq.get() + ",\"unchanged\":true,\"error\":\"state_collection_failed\"}";
        }
    }

    private static String stackJson(class_1799 stack) {
        if (stack == null || stack.method_7960()) return "null";
        String itemId = getItemId(stack);
        return "{\"item\":\"" + escape(itemId) + "\",\"count\":" + stack.method_7947() + "}";
    }

    private static String stackDetailJson(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return "{\"empty\":true,\"item\":null,\"count\":0,\"max_count\":0,\"damage\":0,\"max_damage\":0,\"name\":null}";
        }
        return "{\"empty\":false"
                + ",\"item\":\"" + escape(getItemId(stack)) + "\""
                + ",\"count\":" + stack.method_7947()
                + ",\"max_count\":" + stack.method_7914()
                + ",\"damage\":" + (stack.method_7963() ? stack.method_7919() : 0)
                + ",\"max_damage\":" + (stack.method_7963() ? stack.method_7936() : 0)
                + ",\"name\":\"" + escape(stack.method_7964().getString()) + "\""
                + "}";
    }

    private static String cursorStackJson(class_1799 stack) {
        return stack == null || stack.method_7960() ? "null" : stackDetailJson(stack);
    }

    private static void appendHeldItems(StringBuilder sb, class_746 player) {
        sb.append("\"selected_slot\":").append(player.method_31548().method_67532()).append(",");
        sb.append("\"held_items\":{");
        sb.append("\"main_hand\":").append(stackJson(player.method_6047())).append(",");
        sb.append("\"offhand\":").append(stackJson(player.method_6079()));
        sb.append("},");
    }

    private static void appendEquipment(StringBuilder sb, class_746 player) {
        sb.append("\"equipment\":{");
        sb.append("\"head\":").append(stackJson(player.method_6118(class_1304.field_6169))).append(",");
        sb.append("\"chest\":").append(stackJson(player.method_6118(class_1304.field_6174))).append(",");
        sb.append("\"legs\":").append(stackJson(player.method_6118(class_1304.field_6172))).append(",");
        sb.append("\"feet\":").append(stackJson(player.method_6118(class_1304.field_6166)));
        sb.append("},");
    }

    private static void appendEquipmentDetail(StringBuilder sb, class_746 player) {
        sb.append("\"equipment_detail\":{");
        sb.append("\"main_hand\":").append(stackDetailJson(player.method_6047())).append(",");
        sb.append("\"offhand\":").append(stackDetailJson(player.method_6079())).append(",");
        sb.append("\"armor\":[");
        sb.append("{\"slot\":\"head\",\"stack\":").append(stackDetailJson(player.method_6118(class_1304.field_6169))).append("},");
        sb.append("{\"slot\":\"chest\",\"stack\":").append(stackDetailJson(player.method_6118(class_1304.field_6174))).append("},");
        sb.append("{\"slot\":\"legs\",\"stack\":").append(stackDetailJson(player.method_6118(class_1304.field_6172))).append("},");
        sb.append("{\"slot\":\"feet\",\"stack\":").append(stackDetailJson(player.method_6118(class_1304.field_6166))).append("}");
        sb.append("]");
        sb.append("},");
    }

    private static void appendEffects(StringBuilder sb, class_746 player) {
        sb.append("\"effects\":[");
        java.util.Collection<class_1293> effects = player.method_6026();
        if (effects != null && !effects.isEmpty()) {
            // Sort by effect id for stable ordering
            java.util.List<class_1293> sorted = new java.util.ArrayList<>(effects);
            sorted.sort((a, b) -> {
                String idA = a.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(a.method_5579().comp_349()).toString()
                        : "";
                String idB = b.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(b.method_5579().comp_349()).toString()
                        : "";
                return idA.compareTo(idB);
            });
            boolean first = true;
            for (class_1293 effect : sorted) {
                if (!first) sb.append(",");
                first = false;
                sb.append("{");
                String effectId = effect.method_5579() != null
                        ? net.minecraft.class_7923.field_41174.method_10221(effect.method_5579().comp_349()).toString()
                        : "unknown";
                sb.append("\"id\":\"").append(escape(effectId)).append("\",");
                sb.append("\"amplifier\":").append(effect.method_5578()).append(",");
                sb.append("\"duration_ticks\":").append(effect.method_5584()).append(",");
                sb.append("\"ambient\":").append(effect.method_5591());
                sb.append("}");
            }
        }
        sb.append("],");
    }

    private static void appendXp(StringBuilder sb, class_746 player) {
        sb.append("\"xp\":{");
        sb.append("\"level\":").append(player.field_7520).append(",");
        sb.append("\"progress\":").append(String.format(java.util.Locale.ROOT, "%.2f", player.field_7510));
        sb.append("},");
    }

    private static void appendOpenScreen(StringBuilder sb, class_310 client, class_746 player) {
        sb.append("\"open_screen\":{");
        boolean open = client.field_1755 != null;
        class_1703 handler = open ? player.field_7512 : null;
        sb.append("\"open\":").append(open).append(",");
        sb.append("\"screen_class\":").append(client.field_1755 == null ? "null" : "\"" + escape(client.field_1755.getClass().getName()) + "\"").append(",");
        sb.append("\"handler_class\":").append(handler == null ? "null" : "\"" + escape(handler.getClass().getName()) + "\"").append(",");
        sb.append("\"sync_id\":").append(handler == null ? 0 : handler.field_7763).append(",");
        sb.append("\"slot_count\":").append(handler == null ? 0 : handler.field_7761.size()).append(",");
        appendSlotRange(sb, "container_slots", handler, player, false);
        sb.append(",");
        appendSlotRange(sb, "player_inventory_slots", handler, player, true);
        sb.append(",");
        sb.append("\"cursor\":").append(handler == null ? "null" : cursorStackJson(handler.method_34255())).append(",");
        sb.append("\"slots\":[");
        boolean first = true;
        if (handler != null) {
            for (int i = 0; i < handler.field_7761.size(); i++) {
                class_1735 slot = handler.field_7761.get(i);
                class_1799 stack = slot.method_7677();
                if (stack.method_7960()) continue;
                if (!first) sb.append(",");
                first = false;
                sb.append("{\"slot\":").append(i)
                        .append(",\"section\":\"").append(escape(slotSection(slot, player))).append("\",");
                appendStackDetailFields(sb, stack);
                sb.append("}");
            }
        }
        sb.append("]");
        sb.append("},");
    }

    private static void appendStackDetailFields(StringBuilder sb, class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            sb.append("\"empty\":true,\"item\":null,\"count\":0,\"max_count\":0,\"damage\":0,\"max_damage\":0,\"name\":null");
            return;
        }
        sb.append("\"empty\":false,")
                .append("\"item\":\"").append(escape(getItemId(stack))).append("\",")
                .append("\"count\":").append(stack.method_7947()).append(",")
                .append("\"max_count\":").append(stack.method_7914()).append(",")
                .append("\"damage\":").append(stack.method_7963() ? stack.method_7919() : 0).append(",")
                .append("\"max_damage\":").append(stack.method_7963() ? stack.method_7936() : 0).append(",")
                .append("\"name\":\"").append(escape(stack.method_7964().getString())).append("\"");
    }

    private static void appendSlotRange(StringBuilder sb, String key, class_1703 handler, class_746 player, boolean playerSlots) {
        int first = -1;
        int last = -1;
        if (handler != null) {
            for (int i = 0; i < handler.field_7761.size(); i++) {
                boolean isPlayer = isPlayerSlot(handler.field_7761.get(i), player);
                if (isPlayer == playerSlots) {
                    if (first < 0) first = i;
                    last = i;
                }
            }
        }
        sb.append("\"").append(key).append("\":");
        if (first < 0) {
            sb.append("null");
        } else {
            sb.append("{\"start\":").append(first).append(",\"end\":").append(last).append("}");
        }
    }

    private static boolean isPlayerSlot(class_1735 slot, class_746 player) {
        return slot != null && player != null && slot.field_7871 == player.method_31548();
    }

    private static String slotSection(class_1735 slot, class_746 player) {
        if (!isPlayerSlot(slot, player)) {
            String handler = player != null && player.field_7512 != null
                    ? player.field_7512.getClass().getSimpleName().toLowerCase(Locale.ROOT)
                    : "";
            int index = slot.method_34266();
            if (handler.contains("furnace")) {
                if (index == 2) return "result";
                if (index == 0 || index == 1) return "input";
            }
            if (handler.contains("crafting") || handler.contains("smithing") || handler.contains("anvil")
                    || handler.contains("grindstone") || handler.contains("stonecutter")
                    || handler.contains("loom") || handler.contains("cartography")
                    || handler.contains("brewing") || handler.contains("enchantment")) {
                if (index == 0) return "result";
                return "input";
            }
            return "container";
        }
        int index = slot.method_34266();
        if (index >= 0 && index <= 8) return "hotbar";
        if (index >= 9 && index <= 35) return "player_inventory";
        if (index >= 36 && index <= 39) return "armor";
        if (index == 40) return "offhand";
        return "player_inventory";
    }

    private static void appendTargetedBlock(StringBuilder sb, class_310 client, class_746 player) {
        sb.append("\"targeted_block\":");
        if (client.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332 && client.field_1687 != null) {
            class_2338 pos = hit.method_17777();
            class_2680 state = client.field_1687.method_8320(pos);
            double dist = Math.sqrt(player.method_5707(class_243.method_24953(pos)));
            sb.append("{\"x\":").append(pos.method_10263())
                    .append(",\"y\":").append(pos.method_10264())
                    .append(",\"z\":").append(pos.method_10260())
                    .append(",\"type\":\"").append(escape(getBlockId(state.method_26204()))).append("\"")
                    .append(",\"face\":\"").append(escape(hit.method_17780().name())).append("\"")
                    .append(",\"distance\":").append(round(dist))
                    .append("}");
        } else {
            sb.append("null");
        }
        sb.append(",");
    }

    private static void appendTargetedEntity(StringBuilder sb, class_310 client, class_746 player) {
        sb.append("\"targeted_entity\":");
        if (client.field_1765 instanceof class_3966 hit) {
            class_1297 entity = hit.method_17782();
            double dist = Math.sqrt(player.method_5858(entity));
            sb.append("{\"entity_id\":").append(entity.method_5628())
                    .append(",\"name\":\"").append(escape(entity.method_5477().getString())).append("\"")
                    .append(",\"type\":\"").append(escape(entity.method_5864().toString())).append("\"")
                    .append(",\"x\":").append(round(entity.method_23317()))
                    .append(",\"y\":").append(round(entity.method_23318()))
                    .append(",\"z\":").append(round(entity.method_23321()))
                    .append(",\"distance\":").append(round(dist))
                    .append("}");
        } else {
            sb.append("null");
        }
        sb.append(",");
    }

    private static void appendEnvironment(StringBuilder sb, class_310 client, class_746 player) {
        sb.append("\"environment\":{");
        class_2338 feet = player.method_24515();
        class_2680 feetState = client.field_1687.method_8320(feet);
        class_2680 belowState = client.field_1687.method_8320(feet.method_10074());
        sb.append("\"on_ground\":").append(player.method_24828()).append(",");
        sb.append("\"touching_water\":").append(player.method_5799()).append(",");
        sb.append("\"in_lava\":").append(player.method_5771()).append(",");
        sb.append("\"biome\":\"").append(escape(biomeAt(client.field_1687, feet))).append("\",");
        sb.append("\"light\":").append(client.field_1687.method_22339(feet)).append(",");
        sb.append("\"fluid\":\"").append(escape(fluidAt(feetState))).append("\",");
        sb.append("\"feet_block\":\"").append(escape(getBlockId(feetState.method_26204()))).append("\",");
        sb.append("\"below_block\":\"").append(escape(getBlockId(belowState.method_26204()))).append("\"");
        sb.append("},");
    }

    private static void appendNearbyBlockEntities(StringBuilder sb, class_746 player, class_638 world) {
        sb.append("\"nearby_block_entities\":[");
        boolean first = true;
        int emitted = 0;
        int limit = nearbyBlockEntityLimit();
        int radius = nearbyBlockEntityRadius();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (class_2586 blockEntity : world.method_72019()) {
            if (emitted >= limit) break;
            class_2338 pos = blockEntity.method_11016();
            if (player.method_5707(class_243.method_24953(pos)) > radius * radius) continue;
            class_2680 state = world.method_8320(pos);
            String blockId = getBlockId(state.method_26204());
            if (!isNearbySummaryBlock(blockId)) continue;
            if (!first) sb.append(",");
            first = false;
            emitted++;
            seen.add(pos.method_23854());
            sb.append("{\"x\":").append(pos.method_10263())
                    .append(",\"y\":").append(pos.method_10264())
                    .append(",\"z\":").append(pos.method_10260())
                    .append(",\"type\":\"").append(escape(blockEntity.method_11017().toString())).append("\"")
                    .append(",\"block\":\"").append(escape(getBlockId(state.method_26204()))).append("\"")
                    .append("}");
        }
        class_2338 center = player.method_24515();
        for (int dy = -radius; dy <= radius && emitted < limit; dy++) {
            for (int dz = -radius; dz <= radius && emitted < limit; dz++) {
                for (int dx = -radius; dx <= radius && emitted < limit; dx++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (seen.contains(pos.method_23854())) continue;
                    if (player.method_5707(class_243.method_24953(pos)) > radius * radius) continue;
                    class_2680 state = world.method_8320(pos);
                    String blockId = getBlockId(state.method_26204());
                    if (!isNearbySummaryBlock(blockId)) continue;
                    if (!first) sb.append(",");
                    first = false;
                    emitted++;
                    seen.add(pos.method_23854());
                    sb.append("{\"x\":").append(pos.method_10263())
                            .append(",\"y\":").append(pos.method_10264())
                            .append(",\"z\":").append(pos.method_10260())
                            .append(",\"type\":\"").append(escape(blockId)).append("\"")
                            .append(",\"block\":\"").append(escape(blockId)).append("\"")
                            .append("}");
                }
            }
        }
        sb.append("],");
    }

    private static String targetSignature(class_310 client, class_746 player) {
        if (client.field_1765 instanceof class_3965 hit && hit.method_17783() == class_239.class_240.field_1332 && client.field_1687 != null) {
            class_2338 pos = hit.method_17777();
            return "b:" + pos.method_23854() + ":" + getBlockId(client.field_1687.method_8320(pos).method_26204());
        }
        if (client.field_1765 instanceof class_3966 hit) {
            class_1297 entity = hit.method_17782();
            return "e:" + entity.method_5628() + ":" + entity.method_5864();
        }
        return "none";
    }

    private static String environmentSignature(class_310 client, class_746 player) {
        class_2338 feet = player.method_24515();
        return player.method_24828() + "|" + player.method_5799() + "|" + player.method_5771() + "|"
                + biomeAt(client.field_1687, feet) + "|"
                + client.field_1687.method_22339(feet) + "|"
                + fluidAt(client.field_1687.method_8320(feet)) + "|"
                + getBlockId(client.field_1687.method_8320(feet).method_26204()) + "|"
                + getBlockId(client.field_1687.method_8320(feet.method_10074()).method_26204());
    }

    private static String openScreenSignature(class_310 client, class_746 player) {
        if (client.field_1755 == null || player.field_7512 == null) return "closed";
        class_1703 handler = player.field_7512;
        StringBuilder sig = new StringBuilder();
        sig.append(handler.field_7763).append(':').append(handler.field_7761.size()).append(':');
        for (int i = 0; i < handler.field_7761.size(); i++) {
            class_1735 slot = handler.field_7761.get(i);
            class_1799 stack = slot.method_7677();
            if (stack.method_7960()) continue;
            sig.append(i).append('=').append(getItemId(stack)).append('x').append(stack.method_7947()).append(';');
        }
        class_1799 cursor = handler.method_34255();
        if (!cursor.method_7960()) sig.append("cursor=").append(getItemId(cursor)).append('x').append(cursor.method_7947());
        return sig.toString();
    }

    private static String nearbyBlockEntitiesSignature(class_746 player, class_638 world) {
        StringBuilder sig = new StringBuilder();
        int emitted = 0;
        int limit = nearbyBlockEntityLimit();
        int radius = nearbyBlockEntityRadius();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (class_2586 blockEntity : world.method_72019()) {
            if (emitted >= limit) break;
            class_2338 pos = blockEntity.method_11016();
            if (player.method_5707(class_243.method_24953(pos)) > radius * radius) continue;
            String blockId = getBlockId(world.method_8320(pos).method_26204());
            if (!isNearbySummaryBlock(blockId)) continue;
            emitted++;
            seen.add(pos.method_23854());
            sig.append(pos.method_23854()).append(':').append(blockId).append(':').append(blockEntity.method_11017()).append(';');
        }
        class_2338 center = player.method_24515();
        for (int dy = -radius; dy <= radius && emitted < limit; dy++) {
            for (int dz = -radius; dz <= radius && emitted < limit; dz++) {
                for (int dx = -radius; dx <= radius && emitted < limit; dx++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (seen.contains(pos.method_23854())) continue;
                    if (player.method_5707(class_243.method_24953(pos)) > radius * radius) continue;
                    String blockId = getBlockId(world.method_8320(pos).method_26204());
                    if (!isNearbySummaryBlock(blockId)) continue;
                    emitted++;
                    seen.add(pos.method_23854());
                    sig.append(pos.method_23854()).append(':').append(blockId).append(';');
                }
            }
        }
        return sig.toString();
    }

    private static void appendSurfaceMap(StringBuilder sb, class_746 player, class_638 world, int radius) {
        int centerX = (int) Math.floor(player.method_23317());
        int centerY = (int) Math.floor(player.method_23318());
        int centerZ = (int) Math.floor(player.method_23321());
        sb.append("\"surface_map\":{");
        sb.append("\"center\":{");
        sb.append("\"x\":").append(centerX).append(",");
        sb.append("\"y\":").append(centerY).append(",");
        sb.append("\"z\":").append(centerZ).append("},");
        sb.append("\"radius\":").append(radius).append(",");
        sb.append("\"cells\":[");

        boolean firstCell = true;
        for (int dz = -radius; dz <= radius; dz++) {
            for (int dx = -radius; dx <= radius; dx++) {
                if (!firstCell) sb.append(",");
                firstCell = false;
                int x = centerX + dx;
                int z = centerZ + dz;
                SurfaceCell cell = findTopSurfaceBlock(world, x, z, centerY + Math.min(radius, 32));
                sb.append("{");
                sb.append("\"x\":").append(cell.x).append(",");
                sb.append("\"z\":").append(cell.z).append(",");
                sb.append("\"y\":").append(cell.y).append(",");
                sb.append("\"block\":\"").append(escape(cell.block)).append("\"");
                sb.append("}");
            }
        }
        sb.append("]},");
    }

    private static class SurfaceCell {
        final int x;
        final int y;
        final int z;
        final String block;

        SurfaceCell(int x, int y, int z, String block) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.block = block;
        }
    }

    private static SurfaceCell findTopSurfaceBlock(class_638 world, int x, int z, int startY) {
        for (int y = startY; y >= 0; y--) {
            class_2338 pos = new class_2338(x, y, z);
            if (world == null) break;
            net.minecraft.class_2680 state = world.method_8320(pos);
            if (state == null) continue;
            if (!state.method_26215()) {
                return new SurfaceCell(x, y, z, getBlockId(state.method_26204()));
            }
        }
        return new SurfaceCell(x, 0, z, "minecraft:air");
    }

    /** Minimal JSON string escape. */
    private static String escape(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static String stripChatFormatting(String s) {
        if (s == null) return null;
        return s.replaceAll("\\u00A7[0-9A-FK-ORa-fk-or]", "");
    }

    private static class ChatEvent {
        final String type;
        final String message;
        final String sender;

        ChatEvent(String type, String message, String sender) {
            this.type = type;
            this.message = message;
            this.sender = sender;
        }

        String toJson() {
            return "{\"type\":\"" + escape(type) + "\",\"message\":\"" + escape(message) + "\",\"sender\":" + (sender == null ? "null" : "\"" + escape(sender) + "\"") + "}";
        }
    }

    /**
     * Append craftable items to the JSON builder based on current inventory.
     * Uses simple pattern matching — no RecipeManager needed.
     */
    private static void appendCraftable(StringBuilder sb, class_1661 inv) {
        sb.append("[");
        boolean first = true;

        // Check each known craftable item
        boolean hasLog = hasItemMatching(inv, id -> id.endsWith("_log") || id.endsWith("_stem") || id.endsWith("_hyphae"));
        boolean hasPlank = hasItemMatching(inv, id -> id.endsWith("_planks"));
        boolean hasStick = hasItemNamed(inv, "minecraft:stick");
        int plankCount = countItemMatching(inv, id -> id.endsWith("_planks"));
        int stickCount = countPlanksEquivalent(inv);

        if (hasLog) {
            // Can make planks from any log
            String woodType = findWoodType(inv);
            String planksName = woodType != null ? woodType + "_planks" : "planks";
            appendItem(sb, planksName, first);
            first = false;
        }

        if (hasPlank || hasLog) {
            appendItem(sb, "stick", first);
            first = false;
        }

        if (plankCount >= 4 || (hasLog && hasPlank)) {
            appendItem(sb, "crafting_table", first);
            first = false;
        }

        // Wooden tools (need planks + sticks, or enough planks to make sticks)
        if (plankCount + stickCount >= 3) {
            appendItem(sb, "wooden_pickaxe", first); first = false;
            appendItem(sb, "wooden_axe", first); first = false;
        }
        if (plankCount + stickCount >= 2) {
            appendItem(sb, "wooden_shovel", first); first = false;
            appendItem(sb, "wooden_sword", first); first = false;
            appendItem(sb, "wooden_hoe", first); first = false;
        }

        sb.append("]");
    }

    private static void appendItem(StringBuilder sb, String name, boolean first) {
        if (!first) sb.append(",");
        sb.append("\"").append(name).append("\"");
    }

    private static boolean hasItemMatching(class_1661 inv, java.util.function.Predicate<String> predicate) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && predicate.test(getItemId(stack))) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasItemNamed(class_1661 inv, String exactId) {
        return hasItemMatching(inv, id -> id.equals(exactId));
    }

    private static int countItemMatching(class_1661 inv, java.util.function.Predicate<String> predicate) {
        int count = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && predicate.test(getItemId(stack))) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static int countPlanksEquivalent(class_1661 inv) {
        int total = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            String id = getItemId(stack);
            if (id.equals("minecraft:stick")) {
                total += stack.method_7947() * 2; // 2 planks = 4 sticks → 1 plank = 2 stick equivalent
            } else if (id.endsWith("_planks")) {
                total += stack.method_7947();
            } else if (id.endsWith("_log") || id.endsWith("_stem") || id.endsWith("_hyphae")) {
                total += stack.method_7947() * 4; // 1 log = 4 planks
            }
        }
        return total;
    }

    private static String findWoodType(class_1661 inv) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            String id = getItemId(stack);
            if (id.endsWith("_planks")) {
                return id.substring("minecraft:".length()).replace("_planks", "");
            }
            if (id.endsWith("_log")) {
                return id.substring("minecraft:".length()).replace("_log", "");
            }
        }
        return null;
    }

    private static String round(double v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }

    private static boolean isHostile(class_1297 e) {
        String type = e.method_5864().toString().toLowerCase();
        return type.contains("zombie") || type.contains("skeleton") || type.contains("creeper")
                || type.contains("spider") || type.contains("enderman") || type.contains("witch")
                || type.contains("phantom") || type.contains("slime") || type.contains("drowned")
                || type.contains("husk") || type.contains("stray") || type.contains("pillager")
                || type.contains("vindicator") || type.contains("evoker") || type.contains("ravager")
                || type.contains("vex") || type.contains("silverfish") || type.contains("blaze")
                || type.contains("ghast") || type.contains("magma_cube") || type.contains("piglin")
                || type.contains("hoglin") || type.contains("zoglin") || type.contains("wither_skeleton")
                || type.contains("guardian") || type.contains("elder_guardian");
    }

    // ─── ID helpers ──────────────────────────────────────────────────────────

    /** Strip Item{} wrapper from Item.toString() so "Item{minecraft:stick}" → "minecraft:stick". */
    private static String getItemId(class_1799 stack) {
        if (stack.method_7960()) return "";
        String s = stack.method_7909().toString();
        if (s.startsWith("Item{") && s.endsWith("}")) {
            return s.substring(5, s.length() - 1);
        }
        return s;
    }

    /** Strip Block{} wrapper from Block.toString() so "Block{minecraft:oak_log}" → "minecraft:oak_log". */
    private static String getBlockId(net.minecraft.class_2248 block) {
        String s = block.toString();
        if (s.startsWith("Block{") && s.endsWith("}")) {
            return s.substring(6, s.length() - 1);
        }
        return s;
    }

    private static String fluidAt(class_2680 state) {
        if (state == null || state.method_26227().method_15769()) return "minecraft:empty";
        String s = state.method_26227().method_15772().toString();
        if (s.startsWith("Fluid{") && s.endsWith("}")) {
            return s.substring(6, s.length() - 1);
        }
        return s;
    }

    private static String biomeAt(class_638 world, class_2338 pos) {
        try {
            return world.method_23753(pos).method_40230()
                    .map(key -> key.method_29177().toString())
                    .orElse("unknown");
        } catch (Exception e) {
            return "unknown";
        }
    }

    private static int nearbyBlockEntityRadius() {
        return Math.max(1, Math.min(BridgeConfig.get().nearbyBlockEntityRadius, 32));
    }

    private static int nearbyBlockEntityLimit() {
        return Math.max(1, Math.min(BridgeConfig.get().nearbyBlockEntityLimit, 128));
    }

    private static boolean isNearbySummaryBlock(String blockId) {
        if (blockId == null) return false;
        if (NEARBY_BLOCK_SUMMARY_IDS.contains(blockId)) return true;
        return blockId.endsWith("_bed")
                || blockId.endsWith("_sign")
                || blockId.endsWith("_wall_sign")
                || blockId.endsWith("_hanging_sign")
                || blockId.endsWith("_wall_hanging_sign")
                || blockId.endsWith("_button")
                || blockId.endsWith("_pressure_plate")
                || blockId.endsWith("_shulker_box");
    }
}
