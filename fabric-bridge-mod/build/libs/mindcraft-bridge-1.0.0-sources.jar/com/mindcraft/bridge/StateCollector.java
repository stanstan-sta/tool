package com.mindcraft.bridge;

import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;
import net.minecraft.class_1297;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Collects the current player state into a JSON string.
 *
 * State includes: position, health, hunger, saturation, dimension, game mode,
 * inventory, nearby players, and structured chat events. Chat messages received
 * since the last /state call are appended and then cleared (so callers see only
 * new messages).
 */
public class StateCollector {

            static final Queue<ChatEvent> chatQueue = new ConcurrentLinkedQueue<>();
    static final int MAX_CHAT_QUEUE = 200;
    private static String lastStateHash = "";
    private static final AtomicLong stateSeq = new AtomicLong(0);

    // Track recently-sent chat messages so they can be excluded from the
    // GAME listener, which otherwise echoes them back and causes a loop.
    private static final Queue<String> recentSentChats = new ConcurrentLinkedQueue<>();
    private static final int MAX_SENT_TRACK = 16;

    public static void trackSentChat(String message) {
        while (recentSentChats.size() >= MAX_SENT_TRACK) {
            recentSentChats.poll();
        }
        recentSentChats.add(message);
    }

    /**
     * Register the Fabric chat-receive event listener.
     * Called once from {@link MindcraftBridgeMod#onInitializeClient()}.
     */
    public static void registerEvents() {
        // Listen for incoming chat messages and queue them for the Node.js agent.
        // CHAT covers normal player chat, GAME covers overlay/system messages.
        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
            while (chatQueue.size() >= MAX_CHAT_QUEUE) {
                chatQueue.poll();
            }
            String senderName = null;
            if (sender != null) {
                try {
                    java.lang.reflect.Method method = sender.getClass().getMethod("getName");
                    Object nameObj = method.invoke(sender);
                    if (nameObj != null) {
                        senderName = nameObj.toString();
                    }
                } catch (Throwable ignored) {
                    senderName = sender.toString();
                }
            }
            class_310 client = class_310.method_1551();
            class_746 player = client != null ? client.field_1724 : null;
            if (senderName != null && player != null) {
                String selfName = player.method_5477().getString();
                if (senderName.equals(selfName)) {
                    return;
                }
            }
            chatQueue.add(new ChatEvent("player", message.getString(), senderName));
        });

                        net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            while (chatQueue.size() >= MAX_CHAT_QUEUE) {
                chatQueue.poll();
            }
            String content = message.getString();
            // Skip messages that match a recently sent chat to prevent the
            // echo loop: Node sends "chat:..." → mod sends via network →
            // GAME listener fires with the same text → Node picks it up →
            // LLM responds → repeat.
            if (content != null && recentSentChats.contains(content)) {
                return;
            }
            // Detect Baritone task-queue status messages and route to TaskQueue.
            // The contract: Baritone logs "[Baritone] All queued tasks complete"
            // on success and "[Baritone] Task failed: <label> - <outcome>" on failure.
            if (content != null && content.startsWith("[Baritone]")) {
                if (content.contains("All queued tasks complete")) {
                    TaskQueue.getInstance().onBaritoneComplete();
                    chatQueue.add(new ChatEvent("baritone_queue", content, null));
                } else if (content.startsWith("[Baritone] Task failed:")) {
                    String reason = content.substring("[Baritone] Task failed:".length()).trim();
                    TaskQueue.getInstance().onBaritoneFailed(reason);
                    chatQueue.add(new ChatEvent("baritone_queue", content, null));
                } else {
                    // Other [Baritone] messages — forward as info
                    chatQueue.add(new ChatEvent("baritone_queue", content, null));
                }
                return;
            }
            String type = overlay ? "system" : "player";
            chatQueue.add(new ChatEvent(type, content, null));
        });
    }

    /** Build and return the complete state as a JSON string. */
    public static String collect(Long sinceSeq, boolean includeSurfaceMap, int surfaceRadius) {
        class_310 client = class_310.method_1551();
        class_746 player = client.field_1724;

        if (player == null || client.field_1687 == null) {
            return "{\"connected\":false}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("{");

        sb.append("\"connected\":true,");
        sb.append("\"player_name\":\"").append(escape(player.method_5477().getString())).append("\",");

        // Position
        int x = (int) Math.floor(player.method_23317());
        int y = (int) Math.floor(player.method_23318());
        int z = (int) Math.floor(player.method_23321());
        sb.append(String.format("\"x\":%d,\"y\":%d,\"z\":%d,", x, y, z));

        // Vitals
        sb.append(String.format("\"health\":%.1f,", player.method_6032()));
        sb.append(String.format("\"hunger\":%d,", player.method_7344().method_7586()));
        sb.append(String.format("\"saturation\":%.1f,", player.method_7344().method_7589()));

        // World info
        String dim = client.field_1687.method_27983().method_29177().toString();
        sb.append(String.format("\"dimension\":\"%s\",", dim));

        // Game mode — GameMode.getName() was removed in 1.21.11;
        // use the standard Java enum name() and lower-case it instead.
        String mode = (client.field_1761 != null && client.field_1761.method_2920() != null)
                ? client.field_1761.method_2920().name().toLowerCase()
                : "unknown";
        sb.append(String.format("\"gameMode\":\"%s\",", mode));

        // Inventory
        StringBuilder invSig = new StringBuilder();
        sb.append("\"inventory\":[");
        class_1661 inv = player.method_31548();
        boolean firstItem = true;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            if (!firstItem) sb.append(",");
            firstItem = false;
            String itemId = stack.method_7909().toString(); // "minecraft:oak_log"
            invSig.append(i).append(':').append(itemId).append(':').append(stack.method_7947()).append(';');
            sb.append(String.format("{\"slot\":%d,\"item\":\"%s\",\"count\":%d}",
                    i, escape(itemId), stack.method_7947()));
        }
        sb.append("],");

        // Craftable items based on current inventory
        sb.append("\"craftable\":");
        appendCraftable(sb, inv);
        sb.append(",");

        // Nearby players (within 64 blocks)
        StringBuilder playersSig = new StringBuilder();
        sb.append("\"nearby_players\":[");
        class_238 searchBox = player.method_5829().method_1014(64);
        List<class_1297> entities = client.field_1687.method_8333(player, searchBox,
                e -> e instanceof net.minecraft.class_1657);
        boolean firstPlayer = true;
        for (class_1297 e : entities) {
            if (!firstPlayer) sb.append(",");
            firstPlayer = false;
            playersSig.append(e.method_5477().getString()).append(';');
            sb.append("\"").append(escape(e.method_5477().getString())).append("\"");
        }
        sb.append("],");

        // Nearby non-player entities with precise coordinates and velocity
        StringBuilder entitiesSig = new StringBuilder();
        sb.append("\"nearby_entities\":[");
        List<class_1297> nearbyEntities = client.field_1687.method_8333(player, searchBox,
                e -> !(e instanceof net.minecraft.class_1657));
        boolean firstEntity = true;
        for (class_1297 e : nearbyEntities) {
            if (!firstEntity) sb.append(",");
            firstEntity = false;
            class_243 v = e.method_18798();
            double ex = e.method_23317();
            double ey = e.method_23318();
            double ez = e.method_23321();
            entitiesSig.append(e.method_5864().toString()).append('@')
                    .append(round(ex)).append(',').append(round(ey)).append(',').append(round(ez)).append(';');
            sb.append("{")
                    .append("\"name\":\"").append(escape(e.method_5477().getString())).append("\",")
                    .append("\"type\":\"").append(escape(e.method_5864().toString())).append("\",")
                    .append("\"x\":").append(round(ex)).append(",")
                    .append("\"y\":").append(round(ey)).append(",")
                    .append("\"z\":").append(round(ez)).append(",")
                    .append("\"vx\":").append(round(v.field_1352)).append(",")
                    .append("\"vy\":").append(round(v.field_1351)).append(",")
                    .append("\"vz\":").append(round(v.field_1350))
                    .append("}");
        }
        sb.append("],");

        if (includeSurfaceMap) {
            appendSurfaceMap(sb, player, client.field_1687, surfaceRadius);
        }

        String stateHash = x + "|" + y + "|" + z + "|" + player.method_6032() + "|" +
                player.method_7344().method_7586() + "|" + dim + "|" + mode + "|" +
                invSig + "|" + playersSig + "|" + entitiesSig;
        if (!stateHash.equals(lastStateHash)) {
            lastStateHash = stateHash;
            stateSeq.incrementAndGet();
        }
        long seq = stateSeq.get();

        if (sinceSeq != null && sinceSeq == seq && chatQueue.isEmpty()) {
            return "{\"connected\":true,\"seq\":" + seq + ",\"player_name\":\"" + escape(player.method_5477().getString()) + "\",\"unchanged\":true,\"chat\":[],\"chat_events\":[]}";
        }

        // Chat messages received since last poll — drain the queue into both legacy and structured arrays.
        StringBuilder chatArray = new StringBuilder();
        StringBuilder eventArray = new StringBuilder();
        chatArray.append("[");
        eventArray.append("[");
        boolean firstChat = true;
        boolean firstEvent = true;
        ChatEvent event;
        while ((event = chatQueue.poll()) != null) {
            if (!firstChat) chatArray.append(",");
            firstChat = false;
            chatArray.append("\"").append(escape(event.message)).append("\"");

            if (!firstEvent) eventArray.append(",");
            firstEvent = false;
            eventArray.append(event.toJson());
        }
        chatArray.append("]");
        eventArray.append("]");

        sb.append("\"chat\":").append(chatArray).append(",");
        sb.append("\"chat_events\":").append(eventArray);
        sb.append(",\"seq\":").append(seq);
        sb.append(",\"unchanged\":false");

        // Append task queue state
        TaskQueue.QueueState qs = TaskQueue.getInstance().getQueueState();
        if (!"idle".equals(qs.status()) && !"disabled".equals(qs.status())) {
            sb.append(",\"queue\":{");
            sb.append("\"status\":\"").append(escape(qs.status())).append("\",");
            sb.append("\"active\":").append(qs.active() == null ? "null" : "\"" + escape(qs.active()) + "\"").append(",");
            sb.append("\"pending\":").append(qs.pending()).append(",");
            sb.append("\"paused\":").append(qs.paused());
            if (qs.lastFailure() != null) {
                sb.append(",\"lastFailure\":\"").append(escape(qs.lastFailure())).append("\"");
            }
            sb.append("}");
        }

        sb.append("}");
        return sb.toString();
    }

    private static void appendSurfaceMap(StringBuilder sb, class_746 player, class_638 world, int radius) {
        int centerX = (int) Math.floor(player.method_23317());
        int centerY = (int) Math.floor(player.method_23318());
        int centerZ = (int) Math.floor(player.method_23321());
        sb.append("\"surface_map\":{");
        sb.append("\"center\":{");
        sb.append("\"x\":").append(centerX).append(",");
        sb.append("\"y\":").append(centerY).append(",");
        sb.append("\"z\":").append(centerZ).append("},");
        sb.append("\"radius\":").append(radius).append(",");
        sb.append("\"cells\":[");

        boolean firstCell = true;
        for (int dz = -radius; dz <= radius; dz++) {
            for (int dx = -radius; dx <= radius; dx++) {
                if (!firstCell) sb.append(",");
                firstCell = false;
                int x = centerX + dx;
                int z = centerZ + dz;
                SurfaceCell cell = findTopSurfaceBlock(world, x, z, centerY + Math.min(radius, 32));
                sb.append("{");
                sb.append("\"x\":").append(cell.x).append(",");
                sb.append("\"z\":").append(cell.z).append(",");
                sb.append("\"y\":").append(cell.y).append(",");
                sb.append("\"block\":\"").append(escape(cell.block)).append("\"");
                sb.append("}");
            }
        }
        sb.append("]},");
    }

    private static class SurfaceCell {
        final int x;
        final int y;
        final int z;
        final String block;

        SurfaceCell(int x, int y, int z, String block) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.block = block;
        }
    }

    private static SurfaceCell findTopSurfaceBlock(class_638 world, int x, int z, int startY) {
        for (int y = startY; y >= 0; y--) {
            class_2338 pos = new class_2338(x, y, z);
            if (world == null) break;
            net.minecraft.class_2680 state = world.method_8320(pos);
            if (state == null) continue;
            if (!state.method_26215()) {
                return new SurfaceCell(x, y, z, state.method_26204().toString());
            }
        }
        return new SurfaceCell(x, 0, z, "minecraft:air");
    }

    /** Minimal JSON string escape. */
    private static String escape(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r");
    }

    private static class ChatEvent {
        final String type;
        final String message;
        final String sender;

        ChatEvent(String type, String message, String sender) {
            this.type = type;
            this.message = message;
            this.sender = sender;
        }

        String toJson() {
            return "{\"type\":\"" + escape(type) + "\",\"message\":\"" + escape(message) + "\",\"sender\":" + (sender == null ? "null" : "\"" + escape(sender) + "\"") + "}";
        }
    }

    /**
     * Append craftable items to the JSON builder based on current inventory.
     * Uses simple pattern matching — no RecipeManager needed.
     */
    private static void appendCraftable(StringBuilder sb, class_1661 inv) {
        sb.append("[");
        boolean first = true;

        // Check each known craftable item
        boolean hasLog = hasItemMatching(inv, id -> id.endsWith("_log") || id.endsWith("_stem") || id.endsWith("_hyphae"));
        boolean hasPlank = hasItemMatching(inv, id -> id.endsWith("_planks"));
        boolean hasStick = hasItemNamed(inv, "minecraft:stick");
        int plankCount = countItemMatching(inv, id -> id.endsWith("_planks"));
        int stickCount = countPlanksEquivalent(inv);

        if (hasLog) {
            // Can make planks from any log
            String woodType = findWoodType(inv);
            String planksName = woodType != null ? woodType + "_planks" : "planks";
            appendItem(sb, planksName, first);
            first = false;
        }

        if (hasPlank || hasLog) {
            appendItem(sb, "stick", first);
            first = false;
        }

        if (plankCount >= 4 || (hasLog && hasPlank)) {
            appendItem(sb, "crafting_table", first);
            first = false;
        }

        // Wooden tools (need planks + sticks, or enough planks to make sticks)
        if (plankCount + stickCount >= 3) {
            appendItem(sb, "wooden_pickaxe", first); first = false;
            appendItem(sb, "wooden_axe", first); first = false;
        }
        if (plankCount + stickCount >= 2) {
            appendItem(sb, "wooden_shovel", first); first = false;
            appendItem(sb, "wooden_sword", first); first = false;
            appendItem(sb, "wooden_hoe", first); first = false;
        }

        sb.append("]");
    }

    private static void appendItem(StringBuilder sb, String name, boolean first) {
        if (!first) sb.append(",");
        sb.append("\"").append(name).append("\"");
    }

    private static boolean hasItemMatching(class_1661 inv, java.util.function.Predicate<String> predicate) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && predicate.test(stack.method_7909().toString())) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasItemNamed(class_1661 inv, String exactId) {
        return hasItemMatching(inv, id -> id.equals(exactId));
    }

    private static int countItemMatching(class_1661 inv, java.util.function.Predicate<String> predicate) {
        int count = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && predicate.test(stack.method_7909().toString())) {
                count += stack.method_7947();
            }
        }
        return count;
    }

    private static int countPlanksEquivalent(class_1661 inv) {
        int total = 0;
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            String id = stack.method_7909().toString();
            if (id.equals("minecraft:stick")) {
                total += stack.method_7947() * 2; // 2 planks = 4 sticks → 1 plank = 2 stick equivalent
            } else if (id.endsWith("_planks")) {
                total += stack.method_7947();
            } else if (id.endsWith("_log") || id.endsWith("_stem") || id.endsWith("_hyphae")) {
                total += stack.method_7947() * 4; // 1 log = 4 planks
            }
        }
        return total;
    }

    private static String findWoodType(class_1661 inv) {
        for (int i = 0; i < inv.method_5439(); i++) {
            class_1799 stack = inv.method_5438(i);
            if (stack.method_7960()) continue;
            String id = stack.method_7909().toString();
            if (id.endsWith("_planks")) {
                return id.substring("minecraft:".length()).replace("_planks", "");
            }
            if (id.endsWith("_log")) {
                return id.substring("minecraft:".length()).replace("_log", "");
            }
        }
        return null;
    }

    private static String round(double v) {
        return String.format(Locale.ROOT, "%.2f", v);
    }
}
