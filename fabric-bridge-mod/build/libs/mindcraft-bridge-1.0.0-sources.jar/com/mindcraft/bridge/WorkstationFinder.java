package com.mindcraft.bridge;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class WorkstationFinder {
    private WorkstationFinder() {}

    public static class_2338 findNearest(class_638 world, class_746 player,
                                String blockId, int range) {
        class_2338 playerPos = player.method_24515();
        class_2338.class_2339 mutable = new class_2338.class_2339();
        class_2338 nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    mutable.method_10103(playerPos.method_10263() + dx, playerPos.method_10264() + dy, playerPos.method_10260() + dz);
                    class_2680 state = world.method_8320(mutable);
                    if (state.method_26215()) continue;
                    if (ItemIds.fromBlock(state.method_26204()).equals(blockId)) {
                        double distSq = mutable.method_10262(playerPos);
                        if (distSq < nearestDistSq) {
                            nearestDistSq = distSq;
                            nearest = mutable.method_10062();
                        }
                    }
                }
            }
        }
        return nearest;
    }

    public static class_2338 findNearestStation(class_638 world, class_746 player, String station) {
        return findNearest(world, player, "minecraft:" + station, 16);
    }

    public static class_2338 findNearestOnClientThread(String blockId, int range) {
        return ClientThread.call(() -> {
            class_310 c = class_310.method_1551();
            if (c.field_1724 == null || c.field_1687 == null) return null;
            return findNearest(c.field_1687, c.field_1724, blockId, range);
        });
    }

    public static class_2338 findNearestStationOnClientThread(String station) {
        return findNearestOnClientThread("minecraft:" + station, 16);
    }
}
