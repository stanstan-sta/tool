package com.mindcraft.bridge.utils;

import com.mindcraft.bridge.ClientThread;
import net.minecraft.class_2286;
import net.minecraft.class_2338;
import net.minecraft.class_2462;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_638;

public class BlockStateReader {
    
    public static int getRepeaterDelay(class_638 world, class_2338 pos) {
        return ClientThread.call(() -> {
            class_2680 state = world.method_8320(pos);
            if (state.method_26204() instanceof class_2462) {
                return state.method_11654(class_2741.field_12494);
            }
            return -1;
        });
    }
    
    public static int getComparatorOutput(class_638 world, class_2338 pos) {
        return ClientThread.call(() -> {
            class_2680 state = world.method_8320(pos);
            if (state.method_26204() instanceof class_2286) {
                return state.method_11654(class_2741.field_12511);
            }
            return -1;
        });
    }
    
    public static boolean isRedstonePowered(class_638 world, class_2338 pos) {
        return ClientThread.call(() -> {
            return world.method_49803(pos);
        });
    }
}
