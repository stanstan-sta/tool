/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.renderer.v1.render;

import org.jspecify.annotations.Nullable;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadAtlas;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.item.ItemRenderState;

@FunctionalInterface
public interface ItemRenderTypeGetter {
	/**
	 * Gets the {@link RenderLayer} for the given {@link QuadAtlas} and nullable {@link BlockRenderLayer}. Quads with
	 * matching property values will be rendered using the returned render type.
	 *
	 * <p>A return value of {@code null} means that the current item layer's
	 * {@linkplain ItemRenderState.LayerRenderState#setRenderLayer(RenderLayer) default render type} will be used.
	 */
	@Nullable
	RenderLayer renderType(QuadAtlas quadAtlas, @Nullable BlockRenderLayer sectionLayer);
}
